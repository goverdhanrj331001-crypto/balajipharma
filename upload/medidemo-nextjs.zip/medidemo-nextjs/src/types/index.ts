// ─── Product types ───────────────────────────────────────────────
export type Product = {
  id: string;
  name: string;
  shortName: string;
  brand: string;
  price: number;
  oldPrice?: number;
  note: string;
  icon: string;
  tint: string;
  badge?: string;
};

export type CartItem = Product & { quantity: number };

// ─── Lab test types ──────────────────────────────────────────────
export type LabPackage = {
  id: string;
  name: string;
  detail: string;
  price: string;
  icon: string;
  badge?: string;
};

// ─── Admin types ─────────────────────────────────────────────────
export type AdminDataKind =
  | 'users'
  | 'employees'
  | 'orders'
  | 'medicine'
  | 'lab-orders'
  | 'inventory'
  | 'categories'
  | 'transactions'
  | 'support';

export type OrderStatus = 'Delivered' | 'In Transit' | 'Processing' | 'Pending' | 'Cancelled';
export type StockStatus = 'In Stock' | 'Low Stock' | 'Out of Stock';

// ─── Cart context types ──────────────────────────────────────────
export type CartContextType = {
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  cartCount: number;
  cartTotal: number;
  clearCart: () => void;
};
