import type { Product, LabPackage } from '@/types';

export const products: Product[] = [
  {
    id: 'demo-product-1',
    name: 'Demo Product 1 - Multivitamin Complex 60s',
    shortName: 'Multivitamin Complex',
    brand: 'MediPharma',
    price: 24.99,
    oldPrice: 118,
    note: '60 Capsules',
    icon: 'medication',
    tint: '#d9eeee',
    badge: '15% OFF',
  },
  {
    id: 'demo-product-2',
    name: 'Ashwagandha Extract 500mg 60 Caps',
    shortName: 'Ashwagandha Extract',
    brand: 'Naturals',
    price: 18.5,
    note: '500mg, 90 Tablets',
    icon: 'spa',
    tint: '#e7f0df',
  },
  {
    id: 'demo-product-3',
    name: 'Advanced Blood Glucose Monitor Kit',
    shortName: 'Blood Glucose Monitor',
    brand: 'GlucoCare',
    price: 39.99,
    note: 'Complete monitoring kit',
    icon: 'monitor_heart',
    tint: '#dcecf4',
    badge: 'BESTSELLER',
  },
  {
    id: 'demo-product-4',
    name: 'Fast Acting Muscle Relief Gel 50g',
    shortName: 'Muscle Relief Gel',
    brand: 'ReliefPlus',
    price: 14.5,
    note: '50g tube',
    icon: 'healing',
    tint: '#f2e4d7',
  },
];

export const categories = [
  ['Homeopathy', 'medication', '#e8f5e9'],
  ['Ayurveda', 'spa', '#f1f8e9'],
  ['Vitamins', 'pill', '#f3e5f5'],
  ['Healthcare', 'monitor_heart', '#e1f5fe'],
  ['Sexual Wellness', 'favorite', '#fff3e0'],
  ['Winter Care', 'ac_unit', '#e0f7fa'],
  ['Diabetes Care', 'bloodtype', '#fff8e1'],
  ['Skin Care', 'face', '#f1f8e9'],
  ['Elderly Care', 'elderly', '#fff3e0'],
  ['Supplements', 'fitness_center', '#ffe0b2'],
  ['Health Food', 'nutrition', '#fbe9e7'],
  ['Immunity', 'shield', '#efebe9'],
] as const;

export const labPackages: LabPackage[] = [
  {
    id: 'full-body-checkup',
    name: 'Full Body Checkup',
    detail: 'Includes 85 tests: CBC, Thyroid, Lipid, Liver & more.',
    price: '$149',
    icon: 'favorite',
    badge: '50% OFF',
  },
  {
    id: 'cardiac-profile',
    name: 'Cardiac Profile',
    detail: 'Complete heart health evaluation and lipid panel.',
    price: '$89',
    icon: 'ecg_heart',
  },
  {
    id: 'womens-health',
    name: "Women's Health",
    detail: 'Essential screening including Iron, Thyroid, Vitamin D.',
    price: '$120',
    icon: 'woman',
  },
  {
    id: 'diabetic-screening',
    name: 'Diabetic Screening',
    detail: 'HbA1c, Fasting Sugar, and vital organ screening.',
    price: '$45',
    icon: 'bloodtype',
    badge: 'Popular',
  },
];

export const popularLabTests = [
  { name: 'Complete Blood Count (CBC)', detail: 'Results in 24 hrs', price: '$15' },
  { name: 'Thyroid Profile (T3, T4, TSH)', detail: 'Results in 24 hrs', price: '$25' },
  { name: 'Lipid Profile', detail: 'Fasting required', price: '$20' },
];

export const healthConcerns = [
  'Diabetes care',
  'Cardiac care',
  'Pain relief',
  'Kidney care',
  'Muscle care',
  'Liver care',
  'Respiratory care',
  'Eye care',
  'Mental Wellness',
];

export const featuredBrands = [
  'Himalaya',
  'Horlicks',
  'Dabur',
  'Dr. Morepen',
  'MB',
  'Bourn Vita',
  'mamaearth',
  'JIVA',
  'HealthKart',
];

export const offers = [
  'Flat 25% off + up to $10 cashback',
  'Flat 25% off + up to $10 cashback',
  'Flat 25% off + up to $10 cashback',
];
