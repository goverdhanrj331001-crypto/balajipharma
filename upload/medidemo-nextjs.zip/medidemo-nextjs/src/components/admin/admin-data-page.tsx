import type { AdminDataKind } from '@/types';
import { AdminLayout } from '@/components/admin/admin-layout';
import { StatCard, SectionCard, AdminTable, Toolbar, Pagination } from '@/components/admin/admin-ui';
import { Icon } from '@/components/ui/icon';
import Link from 'next/link';

// ─── Config map ───────────────────────────────────────────────────
const configs: Record<
  AdminDataKind,
  {
    title: string;
    description: string;
    headers: readonly string[];
    rows: readonly (readonly string[])[];
    addLabel?: string;
    addHref?: string;
    statsLabel: string;
    statsValue: string;
    statsIcon: string;
    stats2Label: string;
    stats2Value: string;
    stats2Icon: string;
    stats2Tone?: 'teal' | 'gold' | 'red' | 'blue';
    stats3Label: string;
    stats3Value: string;
    stats3Icon: string;
    stats3Tone?: 'teal' | 'gold' | 'red' | 'blue';
  }
> = {
  users: {
    title: 'User Management',
    description: 'Manage patients, doctors, lab technicians, and administrators.',
    headers: ['User', 'Role', 'Status', 'Last Login'],
    rows: [
      ['Dr. Sarah Jenkins', 'Doctor', 'Active', 'Today, 09:42 AM'],
      ['Marcus Kinsley', 'Patient', 'Active', 'Yesterday, 06:18 PM'],
      ['David Chen', 'Lab Tech', 'Active', 'Aug 14, 2026'],
      ['Elena Rostova', 'Patient', 'Blocked', 'Aug 09, 2026'],
    ],
    addLabel: 'Add User', addHref: '/admin/users/new',
    statsLabel: 'Total Users', statsValue: '18,942', statsIcon: 'group',
    stats2Label: 'Active Today', stats2Value: '89', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
  employees: {
    title: 'Employee Management',
    description: 'Manage the teams that keep MediDemo running.',
    headers: ['Employee', 'Department', 'Status', 'Joined'],
    rows: [
      ['Sarah Jenkins', 'Pharmacists', 'Active', 'Jan 12, 2024'],
      ['Michael Chang', 'Lab Technicians', 'Active', 'Mar 06, 2024'],
      ['David Miller', 'Delivery Partners', 'Active', 'Apr 21, 2024'],
      ['Priya Shah', 'Admin', 'Pending', 'Jun 14, 2024'],
    ],
    addLabel: 'Add Employee', addHref: '/admin/employees/new',
    statsLabel: 'Total Records', statsValue: '1,024', statsIcon: 'badge',
    stats2Label: 'Active Today', stats2Value: '89', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
  orders: {
    title: 'Orders Overview',
    description: 'Review and process medicine and health product orders.',
    headers: ['Order ID', 'Customer', 'Items', 'Delivery Address', 'Status'],
    rows: [
      ['#MD-8492-X', 'Health User', '3 items', '123 Wellness Avenue', 'Delivered'],
      ['#MD-8498-K', 'Ava Morgan', '1 item', '48 Park Lane', 'Processing'],
      ['#MD-8501-Q', 'Marcus Chen', '2 items', '78 Healthway Ave', 'In Transit'],
      ['#MD-8508-P', 'Elena Stone', '4 items', '90 Madison Street', 'Cancelled'],
    ],
    statsLabel: 'Total Orders', statsValue: '1,245', statsIcon: 'receipt_long',
    stats2Label: 'Active Today', stats2Value: '89', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
  medicine: {
    title: 'Medicine Orders',
    description: 'Verify prescriptions and manage medicine fulfillment.',
    headers: ['Order ID', 'Customer', 'Items', 'Order Status', 'Prescription'],
    rows: [
      ['#RX-88421', 'Health User', '3', 'Processing', 'Verified'],
      ['#RX-88422', 'Ava Morgan', '2', 'In Transit', 'Verified'],
      ['#RX-88423', 'Marcus Chen', '1', 'Processing', 'Pending'],
      ['#RX-88424', 'Elena Stone', '5', 'Delivered', 'Verified'],
    ],
    statsLabel: 'Total Orders', statsValue: '1,245', statsIcon: 'medication',
    stats2Label: 'Active Today', stats2Value: '89', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
  'lab-orders': {
    title: 'Lab Testing Orders',
    description: 'Coordinate home sample collection and digital reports.',
    headers: ['Booking ID', 'Patient', 'Test Name', 'Date & Time', 'Status'],
    rows: [
      ['LB-1001', 'Health User', 'Full Body Checkup', 'Aug 16, 09:00 AM', 'Confirmed'],
      ['LB-1002', 'Ava Morgan', 'Thyroid Profile', 'Aug 16, 11:30 AM', 'Processing'],
      ['LB-1003', 'Marcus Chen', 'Lipid Profile', 'Aug 17, 08:00 AM', 'Pending'],
      ['LB-1004', 'Elena Stone', 'CBC', 'Aug 17, 10:00 AM', 'Completed'],
    ],
    statsLabel: 'Total Orders', statsValue: '342', statsIcon: 'science',
    stats2Label: 'Active Today', stats2Value: '89', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
  inventory: {
    title: 'Inventory Management',
    description: 'Monitor stock levels, reorder points, and product availability.',
    headers: ['SKU', 'Product Name', 'Category', 'Current Stock', 'Reorder Level', 'Status'],
    rows: [
      ['MED-001', 'Multivitamin Complex', 'Vitamins', '245', '50', 'In Stock'],
      ['MED-014', 'Ashwagandha Extract', 'Ayurveda', '18', '30', 'Low Stock'],
      ['MED-028', 'Blood Glucose Monitor', 'Healthcare', '0', '20', 'Out of Stock'],
      ['MED-042', 'Muscle Relief Gel', 'Pain Relief', '82', '25', 'In Stock'],
    ],
    addLabel: 'Add Product', addHref: '/admin/inventory/new',
    statsLabel: 'Total Products', statsValue: '2,451', statsIcon: 'inventory_2',
    stats2Label: 'Low Stock', stats2Value: '48', stats2Icon: 'warning', stats2Tone: 'gold',
    stats3Label: 'Out of Stock', stats3Value: '7', stats3Icon: 'error', stats3Tone: 'red',
  },
  categories: {
    title: 'Category Management',
    description: 'Organize the store catalog and health concerns.',
    headers: ['Category', 'Products', 'Visibility', 'Updated'],
    rows: [
      ['Prescription Meds', '86', 'Active', 'Aug 15, 2026'],
      ['Vitamins & Supps', '124', 'Active', 'Aug 12, 2026'],
      ['Lab Packages', '38', 'Active', 'Aug 09, 2026'],
      ['Homeopathy', '52', 'Active', 'Jul 29, 2026'],
    ],
    addLabel: 'Add Category', addHref: '/admin/categories/new',
    statsLabel: 'Total Records', statsValue: '1,024', statsIcon: 'category',
    stats2Label: 'Active Today', stats2Value: '89', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
  transactions: {
    title: 'Transaction History',
    description: 'Track payments, refunds, and settlement activity.',
    headers: ['Transaction ID', 'Order', 'Customer', 'Payment Method', 'Amount', 'Status'],
    rows: [
      ['TXN-78421', '#MD-8492-X', 'Health User', 'Visa •••• 4242', '$142.50', 'Completed'],
      ['TXN-78422', '#MD-8498-K', 'Ava Morgan', 'UPI', '$149.00', 'Completed'],
      ['TXN-78423', '#LB-1003', 'Marcus Chen', 'Wallet', '$25.00', 'Pending'],
      ['TXN-78424', '#MD-8508-P', 'Elena Stone', 'Visa •••• 8801', '$64.50', 'Refunded'],
    ],
    statsLabel: 'Total Records', statsValue: '1,024', statsIcon: 'receipt_long',
    stats2Label: 'Active Today', stats2Value: '89', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
  support: {
    title: 'Support Tickets',
    description: 'Resolve patient questions and service issues.',
    headers: ['Ticket', 'Customer', 'Subject', 'Priority', 'Status'],
    rows: [
      ['#SUP-2201', 'Health User', 'Prescription verification', 'High', 'Open'],
      ['#SUP-2202', 'Ava Morgan', 'Delivery time change', 'Medium', 'In Progress'],
      ['#SUP-2203', 'Marcus Chen', 'Refund request', 'High', 'Open'],
      ['#SUP-2204', 'Elena Stone', 'Lab report question', 'Low', 'Pending'],
    ],
    statsLabel: 'Total Records', statsValue: '1,024', statsIcon: 'support_agent',
    stats2Label: 'Open Tickets', stats2Value: '24', stats2Icon: 'pending_actions', stats2Tone: 'gold',
    stats3Label: 'This Month', stats3Value: '$24,563', stats3Icon: 'trending_up', stats3Tone: 'red',
  },
};

// ─── Exported component ───────────────────────────────────────────
export function AdminDataPage({ kind }: { kind: AdminDataKind }) {
  const cfg = configs[kind];

  return (
    <AdminLayout title={cfg.title}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-[24px] font-extrabold tracking-tight">{cfg.title}</h2>
          <p className="mt-1 max-w-2xl text-[13px] text-[#3e494a]">{cfg.description}</p>
        </div>
        {cfg.addLabel && cfg.addHref && (
          <Link
            href={cfg.addHref}
            className="flex items-center gap-2 rounded-lg bg-[#006872] px-4 py-2.5 text-[12px] font-bold text-white shadow-sm hover:bg-[#00535b]"
          >
            <Icon name="add" className="text-[18px]" /> {cfg.addLabel}
          </Link>
        )}
      </div>

      <div className="mb-5 grid gap-3 sm:grid-cols-3">
        <StatCard label={cfg.statsLabel} value={cfg.statsValue} icon={cfg.statsIcon} />
        <StatCard label={cfg.stats2Label} value={cfg.stats2Value} icon={cfg.stats2Icon} tone={cfg.stats2Tone ?? 'gold'} />
        <StatCard label={cfg.stats3Label} value={cfg.stats3Value} icon={cfg.stats3Icon} tone={cfg.stats3Tone ?? 'red'} />
      </div>

      <SectionCard
        title={cfg.title}
        action={<Toolbar placeholder={`Search ${cfg.title.toLowerCase()}...`} />}
      >
        <AdminTable headers={cfg.headers} rows={cfg.rows} />
      </SectionCard>

      <Pagination />
    </AdminLayout>
  );
}
