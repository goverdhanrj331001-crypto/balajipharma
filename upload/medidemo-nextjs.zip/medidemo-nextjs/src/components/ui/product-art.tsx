import { cn } from '@/lib/utils';
import { Icon } from './icon';

interface ProductArtProps {
  product: { icon: string; tint: string };
  className?: string;
}

export function ProductArt({ product, className = '' }: ProductArtProps) {
  return (
    <div
      className={cn('asset-art flex items-center justify-center', className)}
      style={{ backgroundColor: product.tint }}
    >
      <div className="product-glyph">
        <Icon name={product.icon} className="text-[42px]" />
      </div>
    </div>
  );
}
