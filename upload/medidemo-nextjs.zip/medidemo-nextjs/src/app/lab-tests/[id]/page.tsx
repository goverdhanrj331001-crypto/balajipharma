'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Icon } from '@/components/ui/icon';

function InfoCard({ icon, title, value }: { icon: string; title: string; value: string }) {
  return (
    <div className="flex flex-col items-center rounded-xl border border-[#bdc9ca]/30 bg-[#f5f3f3] p-4 text-center">
      <Icon name={icon} filled className="mb-2 text-[28px] text-[#006872]" />
      <h3 className="text-[12px] font-bold">{title}</h3>
      <p className="text-[14px] text-[#3e494a]">{value}</p>
    </div>
  );
}

const testCategories = [
  { key: 'cbc', icon: 'bloodtype', title: 'Complete Blood Count (CBC)', count: '(24 parameters)', items: ['Hemoglobin', 'Total WBC Count', 'RBC Count', 'Platelet Count'] },
  { key: 'lipid', icon: 'water_drop', title: 'Lipid Profile', count: '(8 parameters)', items: ['Total Cholesterol', 'HDL Cholesterol', 'LDL Cholesterol', 'Triglycerides'] },
  { key: 'liver', icon: 'medical_information', title: 'Liver Function Test', count: '(11 parameters)', items: ['SGOT (AST)', 'SGPT (ALT)', 'Bilirubin Total'] },
  { key: 'thyroid', icon: 'coronavirus', title: 'Thyroid Profile', count: '(3 parameters)', items: ['T3', 'T4', 'TSH'] },
];

export default function LabDetailPage() {
  const [openSection, setOpenSection] = useState('cbc');

  return (
    <div className="app-root page-fade pb-24">
      {/* Desktop header */}
      <header className="sticky top-0 z-50 hidden h-16 items-center justify-between border-b border-[#bdc9ca] bg-[#fbf9f8] px-4 md:flex">
        <Link href="/lab-tests/packages" className="p-2 text-[#3e494a]">
          <Icon name="arrow_back" />
        </Link>
        <span className="text-[24px] font-bold text-[#006872]">MediDemo</span>
        <Link href="/cart" className="p-2 text-[#3e494a]">
          <Icon name="shopping_cart" />
        </Link>
      </header>

      {/* Mobile floating back button */}
      <div className="fixed left-0 right-0 top-0 z-40 flex justify-between p-4 md:hidden">
        <Link href="/lab-tests/packages" className="rounded-full bg-white/85 p-2 shadow-sm">
          <Icon name="arrow_back" />
        </Link>
        <button type="button" className="rounded-full bg-white/85 p-2 shadow-sm">
          <Icon name="share" />
        </button>
      </div>

      <main className="mx-auto max-w-7xl">
        {/* Hero image */}
        <div className="flex h-[40vh] min-h-[280px] items-center justify-center bg-[#d9eeee]">
          <div className="flex h-44 w-44 items-center justify-center rounded-full bg-white shadow-xl">
            <Icon name="medical_information" className="text-[92px] text-[#006872]" />
          </div>
        </div>

        {/* Product info */}
        <section className="-mt-4 rounded-t-3xl bg-[#fbf9f8] px-4 py-6 md:mt-0 md:rounded-none md:py-8">
          <div className="flex items-start justify-between">
            <div>
              <span className="mb-2 inline-flex items-center gap-1 rounded-full bg-[#ffddb5] px-3 py-1 text-[12px] font-bold text-[#835400]">
                <Icon name="star" className="text-[14px]" /> Highly Recommended
              </span>
              <h1 className="text-[20px] font-bold md:text-[24px]">Full Body Checkup</h1>
              <p className="mt-1 flex items-center text-[14px] text-[#3e494a]">
                <Icon name="science" className="mr-2 text-[16px]" />60+ Parameters covered
              </p>
            </div>
            <div className="text-right">
              <p className="text-[24px] font-bold text-[#006872]">$149</p>
              <p className="text-[11px] text-[#3e494a] line-through">$299</p>
            </div>
          </div>
        </section>

        {/* Info cards */}
        <section className="grid grid-cols-2 gap-3 px-4 py-4 md:grid-cols-3">
          <InfoCard icon="schedule" title="Reports within" value="24 Hours" />
          <InfoCard icon="restaurant" title="Preparation" value="10-12 Hrs Fasting" />
          <InfoCard icon="home" title="Sample Collection" value="Free Home Visit" />
        </section>

        {/* Tests included */}
        <section className="border-t border-[#bdc9ca]/30 px-4 py-6">
          <h2 className="mb-4 text-[18px] font-semibold">Tests Included (60+)</h2>
          <div className="space-y-3">
            {testCategories.map(({ key, icon, title, count, items }) => (
              <div key={key} className="soft-card overflow-hidden rounded-xl">
                <button
                  type="button"
                  className="flex w-full items-center justify-between bg-[#f5f3f3]/60 p-4 text-left"
                  onClick={() => setOpenSection(openSection === key ? '' : key)}
                >
                  <span className="flex items-center text-[14px] font-medium">
                    <Icon name={icon} className="mr-3 text-[#006872]" />
                    {title}
                    <small className="ml-2 text-[12px] font-normal text-[#3e494a]">{count}</small>
                  </span>
                  <Icon name={openSection === key ? 'expand_less' : 'expand_more'} className="text-[#3e494a]" />
                </button>
                {openSection === key && (
                  <ul className="list-disc space-y-2 border-t border-[#bdc9ca]/30 p-4 pl-10 text-[14px] text-[#3e494a]">
                    {items.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                )}
              </div>
            ))}
          </div>
          <button
            type="button"
            className="mt-4 w-full rounded-lg border border-[#006872] py-3 text-[14px] font-medium text-[#006872]"
          >
            View all tests
          </button>
        </section>
      </main>

      {/* Sticky CTA */}
      <div className="sticky-action fixed bottom-0 z-50 flex w-full items-center justify-between border-t border-[#bdc9ca] bg-[#fbf9f8] p-4">
        <div>
          <span className="block text-[18px] font-semibold">$149</span>
          <span className="text-[11px] text-[#3e494a]">+ $10 Home Collection</span>
        </div>
        <Link
          href="/lab-tests/schedule"
          className="rounded-lg bg-[#006872] px-8 py-3 text-[14px] font-medium text-white"
        >
          Book Now
        </Link>
      </div>
    </div>
  );
}
