import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { BottomNav } from '@/components/layout/bottom-nav';
import { labPackages } from '@/lib/data';

export default function LabPackagesPage() {
  return (
    <div className="app-root page-fade pb-20">
      <header className="shop-header sticky top-0 z-50 flex h-16 items-center justify-between px-4">
        <Link href="/lab-tests" className="rounded-full p-2 opacity-90">
          <Icon name="arrow_back" />
        </Link>
        <Link href="/lab-tests" className="text-[20px] font-bold">MediDemo</Link>
        <Link href="/cart" className="rounded-full p-2 opacity-90">
          <Icon name="shopping_cart" />
        </Link>
      </header>

      <main className="mx-auto w-full max-w-2xl px-4 py-6">
        <h1 className="mb-6 text-[24px] font-bold">All Health Packages</h1>
        <div className="grid gap-4">
          {labPackages.map((pkg) => (
            <Link
              key={pkg.id}
              href={`/lab-tests/${pkg.id}`}
              className="soft-card flex items-center gap-4 rounded-xl p-4 transition hover:shadow-md"
            >
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-[#d9eeee] text-[#006872]">
                <Icon name={pkg.icon} filled className="text-[32px]" />
              </div>
              <div className="flex-1">
                <h3 className="text-[16px] font-bold">{pkg.name}</h3>
                <p className="mt-1 text-[13px] text-[#3e494a]">{pkg.detail}</p>
              </div>
              <div className="text-right">
                <p className="text-[16px] font-bold text-[#006872]">{pkg.price}</p>
                {pkg.badge && (
                  <span className="rounded-full bg-[#b3272a] px-2 py-0.5 text-[10px] font-bold text-white">
                    {pkg.badge}
                  </span>
                )}
              </div>
              <Icon name="chevron_right" className="text-[#6e797b]" />
            </Link>
          ))}
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
