'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Icon } from '@/components/ui/icon';

const dates = ['Today', 'Tomorrow', 'Mon', 'Tue', 'Wed'];
const times = ['07:00 - 08:00 AM', '08:00 - 09:00 AM', '09:00 - 10:00 AM', '10:00 - 11:00 AM', '12:00 - 01:00 PM', '01:00 - 02:00 PM', '02:00 - 03:00 PM'];

export default function SchedulePage() {
  const [person, setPerson] = useState('Self');
  const [address, setAddress] = useState('Home');
  const [date, setDate] = useState('Today');
  const [time, setTime] = useState('07:00 - 08:00 AM');
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <div className="app-root flex min-h-[100dvh] items-center justify-center p-6">
        <div className="soft-card page-fade max-w-md rounded-2xl p-8 text-center">
          <Icon name="event_available" filled className="text-[58px] text-[#006872]" />
          <h1 className="mt-4 text-[24px] font-bold">Collection scheduled</h1>
          <p className="mt-2 text-[14px] leading-5 text-[#3e494a]">
            Your Full Body Checkup sample collection is booked for {date}, {time}.
          </p>
          <Link
            href="/lab-tests"
            className="mt-6 inline-block rounded-lg bg-[#006872] px-6 py-3 text-[12px] font-bold text-white"
          >
            Back to Lab Tests
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="app-root page-fade min-h-[100dvh] pb-28">
      <header className="sticky top-0 z-50 flex h-16 items-center justify-between border-b border-[#bdc9ca] bg-[#fbf9f8] px-4">
        <Link href="/lab-tests/full-body-checkup" className="p-2 text-[#3e494a]">
          <Icon name="arrow_back" />
        </Link>
        <span className="text-[20px] font-bold text-[#006872]">MediDemo</span>
        <Link href="/cart" className="p-2 text-[#006872]">
          <Icon name="shopping_cart" />
        </Link>
      </header>

      <main className="flex flex-col gap-8 px-4 py-5">
        <div>
          <h1 className="text-[20px] font-bold">Schedule Collection</h1>
          <p className="mt-1 text-[14px] text-[#3e494a]">Complete your booking details below.</p>
        </div>

        {/* Who is this test for */}
        <section>
          <h2 className="mb-3 text-[18px] font-semibold">Who is this test for?</h2>
          <div className="grid grid-cols-2 gap-3">
            {['Self', 'Family Member'].map((item) => (
              <button
                key={item}
                type="button"
                className={`flex items-center gap-2 rounded-xl p-3 text-left text-[12px] font-bold ${
                  person === item
                    ? 'border-2 border-[#006872] bg-white text-[#1b1c1c]'
                    : 'border border-[#bdc9ca] bg-white text-[#3e494a]'
                }`}
                onClick={() => setPerson(item)}
              >
                <Icon name={item === 'Self' ? 'person' : 'group'} filled={person === item} className="text-[#006872]" />
                {item}
              </button>
            ))}
          </div>
        </section>

        {/* Collection address */}
        <section>
          <h2 className="mb-3 text-[18px] font-semibold">Collection Address</h2>
          <div className="flex flex-col gap-3">
            {[
              ['Home', '123 Wellness Ave, Apt 4B', 'home'],
              ['Office', '456 Corporate Blvd, Suite 200', 'domain'],
            ].map(([item, detail, icon]) => (
              <button
                key={item}
                type="button"
                className={`relative flex items-start gap-4 rounded-xl p-4 text-left ${
                  address === item ? 'border-2 border-[#006872] bg-white' : 'border border-[#bdc9ca] bg-white'
                }`}
                onClick={() => setAddress(item)}
              >
                <Icon name={icon} filled={address === item} className={address === item ? 'text-[#006872]' : 'text-[#3e494a]'} />
                <span>
                  <b className="block text-[12px]">{item}</b>
                  <span className="text-[14px] text-[#3e494a]">{detail}<br />New York, NY 10001</span>
                </span>
                {address === item && (
                  <Icon name="check_circle" filled className="absolute right-4 top-4 text-[#006872]" />
                )}
              </button>
            ))}
            <button
              type="button"
              className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-[#6e797b] p-4 text-[12px] font-bold text-[#006872]"
              onClick={() => alert('Address form opened.')}
            >
              <Icon name="add" />Add New Address
            </button>
          </div>
        </section>

        {/* Date selection */}
        <section>
          <h2 className="mb-3 text-[18px] font-semibold">Select Date</h2>
          <div className="flex gap-3 overflow-x-auto no-scrollbar">
            {dates.map((item, i) => (
              <button
                key={item}
                type="button"
                className={`flex h-[104px] w-[88px] shrink-0 flex-col items-center justify-center rounded-xl ${
                  date === item
                    ? 'border-2 border-[#006872] bg-[#006872] text-white'
                    : 'border border-[#bdc9ca] bg-white text-[#3e494a]'
                }`}
                onClick={() => setDate(item)}
              >
                <span className="text-[11px] uppercase">{item}</span>
                <span className="text-[20px] font-bold">{12 + i}</span>
                <span className="text-[12px] font-bold">Oct</span>
              </button>
            ))}
          </div>
        </section>

        {/* Time slots */}
        <section>
          <h2 className="mb-3 text-[18px] font-semibold">Select Time</h2>
          <h3 className="mb-3 flex items-center gap-2 text-[12px] font-bold text-[#3e494a]">
            <Icon name="wb_twilight" className="text-[16px]" />Morning
          </h3>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            {times.map((item) => (
              <button
                key={item}
                type="button"
                className={`rounded-lg px-2 py-3 text-[12px] font-bold ${
                  time === item
                    ? 'border-2 border-[#006872] bg-white text-[#006872]'
                    : 'border border-[#bdc9ca] bg-white'
                }`}
                onClick={() => setTime(item)}
              >
                {item}
              </button>
            ))}
          </div>
        </section>
      </main>

      {/* Sticky CTA */}
      <div className="sticky-action fixed bottom-0 z-50 flex w-full items-center justify-between border-t border-[#bdc9ca] bg-[#fbf9f8] p-4">
        <div>
          <p className="text-[11px] uppercase tracking-wide text-[#3e494a]">Total Payable</p>
          <p className="text-[20px] font-bold text-[#006872]">$145.00</p>
        </div>
        <button
          type="button"
          className="flex items-center gap-2 rounded-lg bg-[#006872] px-6 py-3 text-[12px] font-bold text-white"
          onClick={() => setDone(true)}
        >
          Proceed to Pay <Icon name="arrow_forward" className="text-[18px]" />
        </button>
      </div>
    </div>
  );
}
