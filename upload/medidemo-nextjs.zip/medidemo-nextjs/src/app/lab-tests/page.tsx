'use client';

import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { BottomNav } from '@/components/layout/bottom-nav';
import { labPackages, popularLabTests } from '@/lib/data';

export default function LabTestsPage() {
  return (
    <div className="app-root page-fade pb-20">
      {/* Lab header */}
      <header className="shop-header sticky top-0 z-50 flex h-16 items-center justify-between px-4">
        <Link href="/" className="rounded-full p-2 opacity-90"><Icon name="menu" /></Link>
        <Link href="/lab-tests" className="text-[20px] font-bold">MediDemo</Link>
        <Link href="/cart" className="rounded-full p-2 opacity-90"><Icon name="shopping_cart" /></Link>
      </header>

      <main className="mx-auto w-full max-w-md">
        {/* Medicine / Lab toggle */}
        <div className="mt-4 flex justify-center px-4">
          <div className="flex w-full max-w-xs rounded-full bg-[#eae8e7] p-1">
            <Link href="/" className="flex-1 rounded-full py-2 text-center text-[12px] font-bold text-[#3e494a]">
              Medicine
            </Link>
            <span className="flex-1 rounded-full bg-[#006872] py-2 text-center text-[12px] font-bold text-white">
              Lab Test
            </span>
          </div>
        </div>

        {/* Search */}
        <div className="relative mt-4 px-4">
          <input
            className="w-full rounded-full border border-[#bdc9ca] bg-white py-3 pl-4 pr-12 text-[14px] outline-none focus:border-[#006872]"
            placeholder="Search for Lab Tests or Health Packages"
          />
          <Icon name="search" className="absolute right-6 top-1/2 -translate-y-1/2 text-[#6e797b]" />
        </div>

        {/* Banner */}
        <div className="mt-6 px-4">
          <div className="lab-banner relative overflow-hidden rounded-xl p-4 text-white shadow-sm">
            <div className="relative z-10 w-2/3">
              <h2 className="text-[18px] font-semibold">Book Home Sample Collection</h2>
              <p className="mt-1 text-[14px]">Safe, hygienic, and convenient testing at your doorstep.</p>
              <Link
                href="/lab-tests/schedule"
                className="mt-3 inline-block rounded bg-white px-4 py-2 text-[12px] font-bold text-[#006872]"
              >
                Book Now
              </Link>
            </div>
            <div className="lab-banner-art absolute inset-y-0 right-0 w-2/5 opacity-70">
              <Icon name="home_health" className="absolute right-4 top-1/2 -translate-y-1/2 text-[86px] text-white/50" />
            </div>
          </div>
        </div>

        {/* Featured packages */}
        <div className="mt-8">
          <div className="mb-3 flex items-end justify-between px-4">
            <h2 className="text-[18px] font-semibold">Featured Health Packages</h2>
            <Link href="/lab-tests/packages" className="flex items-center text-[12px] font-bold text-[#006872]">
              View All <Icon name="chevron_right" className="text-[16px]" />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 px-4">
            {labPackages.map((pkg, i) => (
              <Link
                key={pkg.id}
                href={pkg.id === 'full-body-checkup' ? `/lab-tests/${pkg.id}` : '#'}
                className="soft-card relative flex flex-col justify-between rounded-xl p-4 text-left"
              >
                {pkg.badge && (
                  <span className="absolute right-2 top-2 rounded-full bg-[#b3272a] px-2 py-0.5 text-[11px] text-white">
                    {pkg.badge}
                  </span>
                )}
                <Icon
                  name={pkg.icon}
                  filled
                  className={`mb-2 text-[34px] ${i === 1 ? 'text-[#a46a00]' : 'text-[#006872]'}`}
                />
                <h3 className="text-[14px] font-bold">{pkg.name}</h3>
                <p className="mt-1 line-clamp-2 text-[11px] leading-[14px] text-[#3e494a]">{pkg.detail}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-[12px] font-bold">{pkg.price}</span>
                  <span className="text-[12px] font-bold text-[#006872]">Book</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Popular tests */}
        <div className="mt-8">
          <h2 className="mb-3 px-4 text-[18px] font-semibold">Popular Lab Tests</h2>
          <div className="flex flex-col gap-2 px-4">
            {popularLabTests.map(({ name, detail, price }, i) => (
              <div key={name} className="soft-card flex items-center justify-between rounded-lg p-3">
                <div>
                  <h4 className="text-[14px] font-bold">{name}</h4>
                  <p className="text-[11px] text-[#3e494a]">{detail}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[12px] font-bold">{price}</span>
                  <button
                    type="button"
                    className="rounded bg-[#006872] px-3 py-1.5 text-[12px] font-bold text-white"
                  >
                    Add
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* How it works */}
        <div className="mt-8 bg-[#f5f3f3] py-6">
          <h2 className="mb-4 text-center text-[18px] font-semibold">How it works</h2>
          <div className="flex items-start gap-2 px-4 text-center">
            {[
              ['search_check', 'Select Test', 'Choose your required tests online.'],
              ['local_shipping', 'Sample Collection', 'Expert phlebotomist visits your home.'],
              ['description', 'Digital Reports', 'Get accurate reports on your app.'],
            ].map(([icon, title, detail]) => (
              <div key={title} className="flex flex-1 flex-col items-center">
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-white shadow-sm">
                  <Icon name={icon} className="text-[#006872]" />
                </div>
                <h4 className="text-[12px] font-bold">{title}</h4>
                <p className="mt-1 text-[11px] leading-[14px] text-[#3e494a]">{detail}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
