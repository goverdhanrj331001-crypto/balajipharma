'use client';

import Link from 'next/link';
import { StoreHeader } from '@/components/layout/store-header';
import { BottomNav } from '@/components/layout/bottom-nav';
import { ProductBand } from '@/components/store/product-band';
import { Icon } from '@/components/ui/icon';
import { useCart } from '@/lib/cart-context';
import { products, categories, healthConcerns, offers, featuredBrands } from '@/lib/data';

const concernIcons = ['bloodtype', 'favorite', 'healing', 'kidney', 'fitness_center', 'medical_information'];
const concernColors = ['bg-[#eadff3]', 'bg-[#f6dfe4]', 'bg-[#dcecf4]', 'bg-[#f6e4d6]', 'bg-[#d9eeee]', 'bg-[#f2d9d9]'];

export default function HomePage() {
  const { addToCart } = useCart();

  return (
    <div className="app-root page-fade pb-16">
      <StoreHeader />
      <main className="desktop-canvas">
        {/* Hero */}
        <section className="hero-art relative flex h-48 items-center justify-between overflow-hidden px-6 md:h-80 md:px-16">
          <div className="relative z-10 max-w-[58%]">
            <p className="text-[11px] font-bold uppercase tracking-widest text-[#643f00]">Everyday wellness</p>
            <h2 className="mt-1 text-[24px] font-bold leading-8 text-[#2a1800] md:text-[34px]">Boost your immunity</h2>
            <p className="mt-1 text-[14px] text-[#643f00]">Health essentials for brighter days.</p>
            <Link
              href="/products"
              className="mt-4 inline-block rounded-full bg-[#006872] px-4 py-2 text-[12px] font-bold text-white"
            >
              CLICK TO SHOP
            </Link>
          </div>
          <div className="hero-bottle relative mr-8 mt-5 md:mr-28" aria-hidden="true" />
          <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1">
            <i className="h-2 w-2 rounded-full bg-white" />
            <i className="h-2 w-2 rounded-full bg-white/50" />
            <i className="h-2 w-2 rounded-full bg-white/50" />
          </div>
        </section>

        {/* Prescription order */}
        <section className="px-4 py-8 md:px-8">
          <div className="soft-card flex items-center justify-between rounded-xl p-4">
            <div className="max-w-[60%]">
              <h2 className="text-[18px] font-semibold leading-6">Order with prescription</h2>
              <p className="mt-2 text-[14px] leading-5 text-[#3e494a]">
                Upload a prescription and tell us what you need. We do the rest!
              </p>
              <p className="mt-1 text-[12px] font-bold text-[#006872]">Flat 25% off on medicines*</p>
              <Link
                href="/prescriptions"
                className="mt-4 inline-block rounded-lg bg-[#00838f] px-5 py-2 text-[12px] font-bold text-white"
              >
                Order Now
              </Link>
            </div>
            <div className="asset-art flex h-24 w-24 items-center justify-center rounded-xl bg-[#fff3e0]">
              <Icon name="description" className="text-[54px] text-[#a46a00]" />
            </div>
          </div>
        </section>

        {/* Popular categories */}
        <section className="bg-[#f5f3f3] px-4 py-4 md:px-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-[18px] font-semibold leading-6">Popular categories</h2>
            <Link
              href="/categories"
              className="rounded bg-[#006872] px-3 py-1 text-[12px] font-bold text-white"
            >
              VIEW ALL
            </Link>
          </div>
          <div className="grid grid-cols-3 gap-2 md:grid-cols-6">
            {categories.map(([name, icon, tint]) => (
              <Link
                key={name}
                href="/categories"
                className="soft-card rounded-lg p-2 transition hover:shadow-md active:scale-95"
              >
                <div
                  className="flex aspect-square items-center justify-center rounded-md"
                  style={{ background: tint }}
                >
                  <Icon name={icon} className="text-[34px] text-[#006872]" />
                </div>
                <span className="mt-2 block truncate text-center text-[11px] font-medium">{name}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Daily essentials banner */}
        <section className="px-4 py-4 md:px-8">
          <div className="relative flex h-32 items-center overflow-hidden rounded-xl bg-[#4caf50] px-6 text-white md:h-48">
            <div className="relative z-10">
              <p className="text-[11px] uppercase tracking-wider">Daily health</p>
              <h3 className="text-[24px] font-bold leading-8">Essentials</h3>
              <p className="text-[14px]">UP TO <b className="text-[18px]">30% off</b></p>
              <Link href="/products" className="mt-2 flex items-center gap-2 text-[12px] font-bold">
                SHOP NOW
                <Icon name="arrow_forward" className="rounded-full bg-white p-1 text-[16px] text-[#4caf50]" />
              </Link>
            </div>
            <Icon name="medication" className="absolute right-12 text-[100px] text-white/25" />
          </div>
        </section>

        {/* Call banner */}
        <section className="border-y border-[#bdc9ca]/30 bg-white px-4 py-4 md:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-[18px] font-semibold">Call to order medicines</h2>
              <p className="text-[14px] text-[#3e494a]">Need medicine without any hassle? call us now</p>
            </div>
            <button
              type="button"
              className="rounded bg-[#006872] px-4 py-2 text-[12px] font-bold text-white"
              onClick={() => alert('Our pharmacy team is ready to help.')}
            >
              Call Now
            </button>
          </div>
        </section>

        {/* Product bands */}
        <ProductBand title="Healthcare Products" color="#ef5350" products={products} onAdd={addToCart} />

        {/* Offers */}
        <section className="px-4 py-4 md:px-8">
          <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
            {offers.map((offer, i) => (
              <div key={i} className="soft-card flex min-w-[280px] items-center gap-3 rounded-lg p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#ffddb5] text-lg font-bold text-[#835400]">
                  %
                </div>
                <div>
                  <p className="text-[11px] font-semibold">{offer}</p>
                  <p className="text-[11px] text-[#3e494a]">Code: <b>MEDI25</b></p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Health concerns */}
        <section className="px-4 py-4 md:px-8">
          <h2 className="mb-4 text-[18px] font-semibold">Shop by health concerns</h2>
          <div className="grid grid-cols-3 gap-3 md:grid-cols-6">
            {healthConcerns.map((name, i) => (
              <Link key={name} href="/products" className="group text-center">
                <div
                  className={`asset-art flex aspect-square items-center justify-center rounded-xl ${concernColors[i % 6]}`}
                >
                  <Icon
                    name={concernIcons[i % 6]}
                    className="text-[34px] text-[#006872] transition group-hover:scale-110"
                  />
                </div>
                <span className="mt-2 block text-[11px] font-medium">{name}</span>
              </Link>
            ))}
          </div>
        </section>

        <ProductBand title="Winter Care" color="#1976d2" products={products.slice(0, 3)} onAdd={addToCart} />
        <ProductBand title="Immunity Boosters" color="#26a69a" products={products.slice(0, 3)} onAdd={addToCart} />

        {/* Featured brands */}
        <section className="px-4 py-6 md:px-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-[18px] font-semibold">Featured brands</h2>
            <button type="button" className="rounded bg-[#006872] px-3 py-1 text-[12px] font-bold text-white">
              VIEW ALL
            </button>
          </div>
          <div className="grid grid-cols-3 gap-3 md:grid-cols-6">
            {featuredBrands.map((brand) => (
              <div
                key={brand}
                className="soft-card flex aspect-[4/3] items-center justify-center rounded-lg p-2 text-center text-[12px] font-bold text-[#006872]"
              >
                {brand}
              </div>
            ))}
          </div>
        </section>
      </main>
      <BottomNav />
    </div>
  );
}
