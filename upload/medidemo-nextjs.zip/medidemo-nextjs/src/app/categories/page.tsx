'use client';

import Link from 'next/link';
import { StoreHeader } from '@/components/layout/store-header';
import { BottomNav } from '@/components/layout/bottom-nav';
import { Icon } from '@/components/ui/icon';
import { categories } from '@/lib/data';

export default function CategoriesPage() {
  return (
    <div className="app-root page-fade pb-16">
      <StoreHeader search={false} />
      <main className="mx-auto w-full max-w-3xl px-4 pt-4 md:pt-6">
        {/* Sticky search */}
        <div className="sticky top-16 z-40 mb-6 bg-[#fbf9f8] py-2">
          <div className="relative">
            <input
              className="w-full rounded-full border border-[#bdc9ca] bg-white py-3 pl-12 pr-4 text-[14px] outline-none focus:border-[#006872]"
              placeholder="Search medicines & health products"
            />
            <Icon name="search" className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6e797b]" />
          </div>
        </div>

        {/* Category grid */}
        <div className="grid grid-cols-3 gap-2 md:grid-cols-4 md:gap-4">
          {categories.map(([name, icon, tint]) => (
            <Link
              key={name}
              href="/products"
              className="soft-card rounded-xl p-2 transition hover:shadow-md active:scale-95"
            >
              <div
                className="flex aspect-square items-center justify-center rounded-lg"
                style={{ background: tint }}
              >
                <Icon name={icon} className="text-[42px] text-[#006872]" />
              </div>
              <h3 className="mt-3 truncate text-center text-[12px] font-bold">{name}</h3>
            </Link>
          ))}
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
