'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { BottomNav } from '@/components/layout/bottom-nav';

const profileRows = [
  ['My Prescriptions', 'Manage active and past prescriptions', 'description', '/prescriptions'],
  ['Health Records', 'Lab results and consultation history', 'folder_shared', ''],
  ['Medicine Wallet', 'Saved payment methods and balances', 'account_balance_wallet', ''],
  ['Order History', 'Track past and current deliveries', 'receipt_long', '/orders'],
  ['Settings', '', 'settings', ''],
] as const;

export default function ProfilePage() {
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  return (
    <div className="profile-shell flex min-h-[100dvh] flex-col">
      {/* Desktop header */}
      <header className="top-bar sticky top-0 z-40 hidden w-full items-center justify-between px-4 md:flex">
        <div className="flex items-center gap-4">
          <button type="button" className="top-bar-button rounded-full p-2 text-[#3e494a]">
            <Icon name="menu" />
          </button>
          <h1 className="text-[20px] font-bold text-[#006872]">MediDemo</h1>
        </div>
        <nav className="flex gap-2">
          {['Home', 'Health', 'Orders', 'Profile'].map((item) => (
            <Link
              key={item}
              href={item === 'Home' ? '/' : item === 'Orders' ? '/orders' : '#'}
              className={`rounded-md px-3 py-2 text-[12px] font-bold ${
                item === 'Profile' ? 'bg-[#f0eded] text-[#006872]' : 'text-[#3e494a]'
              }`}
            >
              {item}
            </Link>
          ))}
        </nav>
        <button
          type="button"
          className="top-bar-button rounded-full p-2 text-[#006872]"
          onClick={() => alert('No new notifications.')}
        >
          <Icon name="notifications" />
        </button>
      </header>

      <main className="flex-1 pb-24 md:pb-8">
        {/* Profile hero */}
        <section className="profile-hero mx-auto flex w-full max-w-3xl flex-col items-center bg-[#f5f3f3] px-4 pb-6 pt-8 text-center md:mt-6 md:rounded-2xl md:bg-transparent">
          <div className="relative mb-4 h-24 w-24">
            <div className="flex h-full w-full items-center justify-center rounded-full border-4 border-white bg-[#d9eeee] text-[24px] font-bold text-[#006872] shadow-sm">
              HU
            </div>
            <span className="verified-mark absolute bottom-0 right-0 flex items-center justify-center rounded-full text-white">
              <Icon name="verified" filled className="text-[16px]" />
            </span>
          </div>
          <h2 className="text-[20px] font-bold">Health User</h2>
          <div className="premium-badge mt-1 flex items-center gap-2 rounded-full px-3 py-1">
            <Icon name="star" filled className="text-[14px]" />
            <span className="text-[12px] font-bold">Premium Member</span>
          </div>
        </section>

        {/* Menu rows */}
        <section className="mx-auto w-full max-w-3xl px-4 py-6">
          <div className="flex flex-col gap-3">
            {profileRows.map(([title, description, icon, path], i) => (
              path ? (
                <Link
                  key={title}
                  href={path}
                  className={`account-row flex items-center justify-between rounded-xl border bg-[#fbf9f8] p-4 ${i === 4 ? 'mt-3' : ''}`}
                >
                  <span className="flex items-center gap-4">
                    <span className={`account-icon flex items-center justify-center rounded-full ${i === 4 ? 'settings-icon' : ''}`}>
                      <Icon name={icon} />
                    </span>
                    <span>
                      <span className="block text-[16px] font-medium">{title}</span>
                      {description && <span className="block text-[11px] text-[#3e494a]">{description}</span>}
                    </span>
                  </span>
                  <Icon name="chevron_right" className="text-[#6e797b]" />
                </Link>
              ) : (
                <button
                  key={title}
                  type="button"
                  className={`account-row flex items-center justify-between rounded-xl border bg-[#fbf9f8] p-4 text-left ${i === 4 ? 'mt-3' : ''}`}
                >
                  <span className="flex items-center gap-4">
                    <span className={`account-icon flex items-center justify-center rounded-full ${i === 4 ? 'settings-icon' : ''}`}>
                      <Icon name={icon} />
                    </span>
                    <span>
                      <span className="block text-[16px] font-medium">{title}</span>
                      {description && <span className="block text-[11px] text-[#3e494a]">{description}</span>}
                    </span>
                  </span>
                  <Icon name="chevron_right" className="text-[#6e797b]" />
                </button>
              )
            ))}
          </div>

          {/* Logout */}
          <div className="mt-8">
            {showLogoutConfirm ? (
              <div className="feedback rounded-lg border border-[#ffdad6] bg-[#fff4f2] p-4 text-center">
                <p className="text-[14px] font-semibold text-[#600009]">Are you sure you want to log out?</p>
                <div className="mt-3 flex justify-center gap-2">
                  <button
                    type="button"
                    className="rounded border border-[#ba1a1a] px-4 py-2 text-[12px] font-bold text-[#ba1a1a]"
                    onClick={() => setShowLogoutConfirm(false)}
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="rounded bg-[#ba1a1a] px-4 py-2 text-[12px] font-bold text-white"
                    onClick={() => setShowLogoutConfirm(false)}
                  >
                    Log Out
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                className="logout-button flex w-full items-center justify-center gap-2 rounded-lg border py-3 text-[12px] font-bold"
                onClick={() => setShowLogoutConfirm(true)}
              >
                <Icon name="logout" />Log Out
              </button>
            )}
          </div>
        </section>
      </main>
      <BottomNav />
    </div>
  );
}
