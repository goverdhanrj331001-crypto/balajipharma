'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Icon } from '@/components/ui/icon';

export default function CheckoutPage() {
  const router = useRouter();
  const [slot, setSlot] = useState('Today');
  const [payment, setPayment] = useState('Card');
  const [placed, setPlaced] = useState(false);

  if (placed) {
    return (
      <div className="app-root flex min-h-[100dvh] items-center justify-center p-6">
        <div className="soft-card page-fade max-w-md rounded-2xl p-8 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#d9eeee] text-[#006872]">
            <Icon name="check_circle" filled className="text-[42px]" />
          </div>
          <h1 className="mt-5 text-[24px] font-bold">Order placed</h1>
          <p className="mt-2 text-[14px] leading-5 text-[#3e494a]">
            Your pharmacy order is confirmed and will arrive in the selected delivery slot.
          </p>
          <Link
            href="/orders"
            className="mt-6 inline-block rounded-lg bg-[#006872] px-6 py-3 text-[12px] font-bold text-white"
          >
            View Orders
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="app-root page-fade flex min-h-[100dvh] flex-col pb-24">
      <header className="fixed top-0 z-50 flex h-16 w-full items-center justify-between border-b border-[#bdc9ca] bg-[#fbf9f8] px-4">
        <Link href="/cart" className="rounded-full p-2 text-[#3e494a]">
          <Icon name="arrow_back" />
        </Link>
        <h1 className="truncate text-[20px] font-bold text-[#006872]">Checkout</h1>
        <span className="w-10" />
      </header>

      <main className="mx-auto flex w-full max-w-2xl flex-1 flex-col gap-6 px-4 py-20">
        {/* Delivery Address */}
        <section className="soft-card rounded-xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-[18px] font-semibold">
              <Icon name="location_on" filled className="text-[#006872]" />
              Delivery Address
            </h2>
            <button type="button" className="text-[12px] font-bold uppercase tracking-wider text-[#006872]">
              Change
            </button>
          </div>
          <div className="ml-8 text-[14px] leading-5 text-[#3e494a]">
            <p className="font-medium text-[#1b1c1c]">Jane Doe</p>
            <p>123 Wellness Avenue, Suite 4B</p>
            <p>Healthcare District, NY 10001</p>
            <p className="mt-1">+1 (555) 123-4567</p>
          </div>
        </section>

        {/* Delivery Slot */}
        <section className="soft-card rounded-xl p-4">
          <h2 className="mb-4 flex items-center gap-2 text-[18px] font-semibold">
            <Icon name="schedule" filled className="text-[#006872]" />
            Delivery Slot
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {['Today', 'Tomorrow'].map((item) => (
              <button
                key={item}
                type="button"
                className={`rounded-lg p-3 text-center ${
                  slot === item
                    ? 'border-2 border-[#006872] bg-[#d9eeee]'
                    : 'border border-[#bdc9ca] bg-white'
                }`}
                onClick={() => setSlot(item)}
              >
                <p className="text-[12px] font-bold text-[#006872]">{item}</p>
                <p className="text-[14px]">{item === 'Today' ? '2:00 PM - 5:00 PM' : '9:00 AM - 12:00 PM'}</p>
              </button>
            ))}
          </div>
        </section>

        {/* Payment */}
        <section className="soft-card rounded-xl p-4">
          <h2 className="mb-4 flex items-center gap-2 text-[18px] font-semibold">
            <Icon name="payment" filled className="text-[#006872]" />
            Payment Method
          </h2>
          <div className="space-y-2">
            {[
              ['Card', 'credit_card', '•••• •••• •••• 4242', 'Visa - Expires 12/25'],
              ['UPI', 'qr_code_scanner', 'UPI / Wallet', ''],
              ['Cash', 'local_shipping', 'Cash on Delivery', 'Pay when you receive'],
            ].map(([key, icon, title, detail]) => (
              <button
                key={key}
                type="button"
                className={`flex w-full items-center rounded-lg border p-3 text-left ${
                  payment === key ? 'border-[#006872] bg-[#d9eeee]/40' : 'border-[#bdc9ca]'
                }`}
                onClick={() => setPayment(key)}
              >
                <span
                  className={`mr-3 flex h-4 w-4 items-center justify-center rounded-full border ${
                    payment === key ? 'border-4 border-[#006872]' : 'border-[#6e797b]'
                  }`}
                />
                <Icon name={icon} className="mr-3 text-[#3e494a]" />
                <span>
                  <span className="block text-[14px] font-medium">{title}</span>
                  {detail && <span className="block text-[11px] text-[#3e494a]">{detail}</span>}
                </span>
              </button>
            ))}
          </div>
        </section>

        {/* Order summary */}
        <section className="soft-card rounded-xl p-4">
          <h2 className="mb-4 flex items-center gap-2 text-[18px] font-semibold">
            <Icon name="receipt_long" filled className="text-[#006872]" />
            Order Summary
          </h2>
          <div className="space-y-3 text-[14px]">
            <div className="flex justify-between"><span className="text-[#3e494a]">Items (3)</span><span>$45.50</span></div>
            <div className="flex justify-between"><span className="text-[#3e494a]">Delivery Fee</span><span>$5.00</span></div>
            <div className="flex justify-between text-[#006872]"><span>Discount Applied</span><span>-$2.50</span></div>
            <div className="flex justify-between border-t border-[#bdc9ca]/30 pt-3 text-[18px] font-semibold">
              <span>Total Amount</span>
              <span className="text-[#006872]">$48.00</span>
            </div>
          </div>
        </section>
      </main>

      <div className="sticky-action fixed bottom-0 z-40 w-full border-t border-[#bdc9ca] bg-[#fbf9f8] p-4">
        <div className="mx-auto flex max-w-2xl items-center gap-4">
          <div>
            <p className="text-[11px] text-[#3e494a]">Total to pay</p>
            <p className="text-[20px] font-bold text-[#006872]">$48.00</p>
          </div>
          <button
            type="button"
            className="flex-1 rounded bg-[#006872] py-3 text-[12px] font-bold uppercase tracking-wide text-white"
            onClick={() => setPlaced(true)}
          >
            Place Order <Icon name="arrow_forward" className="ml-1 align-middle text-[16px]" />
          </button>
        </div>
      </div>
    </div>
  );
}
