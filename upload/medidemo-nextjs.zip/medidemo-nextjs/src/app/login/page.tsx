'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Icon } from '@/components/ui/icon';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setMessage('Enter your details to continue.');
      return;
    }
    setMessage('Welcome back. Redirecting to your dashboard...');
    setTimeout(() => router.push('/admin/dashboard'), 250);
  };

  return (
    <div className="login-page relative flex min-h-[100dvh] items-center justify-center overflow-hidden bg-[#fbf9f8] p-4">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-[#75d5e2]/20 to-transparent" />
      <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-[#92f1fe]/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-[#ffdad7]/20 blur-3xl" />

      <main className="relative z-10 flex w-full max-w-md flex-col gap-6 rounded-xl border border-[#bdc9ca] bg-white p-6 shadow-sm sm:p-8">
        <div className="flex flex-col items-center justify-center gap-2 text-center">
          <div className="mb-2 flex h-16 w-16 items-center justify-center rounded-xl bg-[#00838f] text-white shadow-sm">
            <Icon name="local_hospital" className="text-[32px]" />
          </div>
          <h1 className="text-[20px] font-bold">Welcome Back</h1>
          <p className="text-[14px] text-[#3e494a]">Sign in to your MediDemo admin portal.</p>
        </div>

        <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
          <label className="block">
            <span className="mb-1.5 block text-[12px] font-bold">Phone Number or Email</span>
            <div className="relative">
              <Icon name="person" className="absolute left-3 top-1/2 -translate-y-1/2 text-[20px] text-[#3e494a]" />
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="h-11 w-full rounded-lg border border-[#bdc9ca] bg-[#fbf9f8] pl-10 pr-3 text-[14px] outline-none focus:border-[#006872] focus:ring-1 focus:ring-[#006872]"
                placeholder="Enter details"
              />
            </div>
          </label>

          <label className="block">
            <span className="mb-1.5 flex items-center justify-between text-[12px] font-bold">
              <span>Password</span>
              <button
                type="button"
                className="text-[#006872]"
                onClick={() => setMessage('Password reset instructions are ready.')}
              >
                Forgot Password?
              </button>
            </span>
            <div className="relative">
              <Icon name="lock" className="absolute left-3 top-1/2 -translate-y-1/2 text-[20px] text-[#3e494a]" />
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                type={showPassword ? 'text' : 'password'}
                className="h-11 w-full rounded-lg border border-[#bdc9ca] bg-[#fbf9f8] pl-10 pr-11 text-[14px] outline-none focus:border-[#006872] focus:ring-1 focus:ring-[#006872]"
                placeholder="Enter password"
              />
              <button
                type="button"
                className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-[#3e494a] hover:bg-[#f0eded]"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                <Icon name={showPassword ? 'visibility' : 'visibility_off'} className="text-[20px]" />
              </button>
            </div>
          </label>

          <button
            type="submit"
            className="h-11 w-full rounded-lg bg-[#00838f] text-[12px] font-bold text-white shadow-sm transition hover:bg-[#006872]"
          >
            Continue
          </button>

          <div className="flex items-center gap-3 py-1">
            <div className="h-px flex-1 bg-[#bdc9ca]" />
            <span className="text-[11px] uppercase tracking-wider text-[#3e494a]">Or</span>
            <div className="h-px flex-1 bg-[#bdc9ca]" />
          </div>

          <button
            type="button"
            className="flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-[#bdc9ca] bg-white text-[12px] font-bold text-[#006872] hover:bg-[#f5f3f3]"
            onClick={() => setMessage('OTP login is ready for your phone number.')}
          >
            <Icon name="dialpad" className="text-[18px]" /> Login with OTP
          </button>

          <button
            type="button"
            className="h-11 w-full rounded-lg text-[12px] font-bold text-[#3e494a] hover:bg-[#f0eded]"
            onClick={() => setMessage('Account creation is ready for this demo.')}
          >
            Create Account
          </button>

          {message && (
            <p className="feedback rounded-lg bg-[#d9eeee] p-3 text-center text-[12px] font-bold text-[#006872]">
              {message}
            </p>
          )}
        </form>
      </main>
    </div>
  );
}
