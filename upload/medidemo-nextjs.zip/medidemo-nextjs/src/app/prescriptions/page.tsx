'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { BottomNav } from '@/components/layout/bottom-nav';

const prescriptions = [
  ['Amoxicillin 500mg', 'Dr. Sarah Jenkins', 'Oct 12, 2023', 'Verified', 'description', 0],
  ['Lisinopril 10mg', 'Dr. Michael Chen', 'Oct 28, 2023', 'Pending', 'description', 1],
  ['Atorvastatin 20mg', 'Dr. Emily Stone', 'Jan 15, 2023', 'Expired', 'history', 2],
] as const;

export default function PrescriptionsPage() {
  const [message, setMessage] = useState('');

  return (
    <div className="app-root page-fade pb-24 md:pl-80">
      {/* Mobile header */}
      <header className="flex h-16 items-center justify-between bg-[#fbf9f8] px-4 md:hidden">
        <Link href="/profile" className="p-2 text-[#006872]"><Icon name="menu" /></Link>
        <span className="text-[20px] font-bold text-[#006872]">MediDemo</span>
        <Icon name="notifications" className="text-[#006872]" />
      </header>

      {/* Desktop sidebar */}
      <aside className="side-drawer fixed inset-y-0 left-0 z-40 hidden w-80 bg-[#fbf9f8] p-6 md:block">
        <div className="flex items-center gap-4 border-b border-[#f0eded] pb-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#d9eeee] text-[#006872]">
            <Icon name="person" />
          </div>
          <div>
            <div className="text-[18px] font-semibold">Health User</div>
            <div className="text-[14px] text-[#3e494a]">Premium Member</div>
            <div className="mt-1 text-[11px] text-[#006872]">Verified Profile</div>
          </div>
        </div>
        <span className="mt-6 flex w-full items-center gap-3 rounded-full bg-[#fc5d59] px-4 py-3 text-[14px] font-bold text-[#600009]">
          <Icon name="description" />My Prescriptions
        </span>
        <Link href="/orders" className="mt-2 flex w-full items-center gap-3 rounded-full px-4 py-3 text-[14px] text-[#3e494a]">
          <Icon name="receipt_long" />Order History
        </Link>
      </aside>

      <main className="mx-auto max-w-5xl p-4 md:p-8">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h1 className="text-[24px] font-bold">My Prescriptions</h1>
            <p className="mt-2 text-[14px] text-[#3e494a]">Manage and view your uploaded prescriptions.</p>
          </div>
          <button
            type="button"
            className="hidden rounded-lg bg-[#006872] px-6 py-3 text-[12px] font-bold text-white md:flex"
            onClick={() => setMessage('Prescription upload is ready for this demo.')}
          >
            <Icon name="upload" className="mr-2" />Upload New Prescription
          </button>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {prescriptions.map(([name, doctor, date, status, icon, i]) => (
            <article
              key={name}
              className={`soft-card relative overflow-hidden rounded-xl p-5 ${i === 2 ? 'opacity-75' : ''}`}
            >
              <div
                className={`absolute left-0 top-0 h-full w-1 ${
                  i === 0 ? 'bg-[#006872]' : i === 1 ? 'bg-[#fc5d59]' : 'bg-[#dcd9d9]'
                }`}
              />
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#d9eeee] text-[#006872]">
                    <Icon name={icon} />
                  </div>
                  <div>
                    <h3 className={`text-[16px] font-semibold ${i === 2 ? 'line-through' : ''}`}>{name}</h3>
                    <p className="text-[13px] text-[#3e494a]">{doctor}</p>
                  </div>
                </div>
                <span className="rounded-full bg-[#eae8e7] px-2 py-1 text-[11px] text-[#3e494a]">{status}</span>
              </div>
              <div className="mt-4 flex items-center justify-between border-t border-[#e4e2e1] pt-4">
                <span className="flex items-center text-[12px] text-[#3e494a]">
                  <Icon name="calendar_today" className="mr-1 text-[16px]" />
                  {date}
                </span>
                <button
                  type="button"
                  className="flex items-center text-[12px] font-bold text-[#006872]"
                  onClick={() => setMessage(`${name} details opened.`)}
                >
                  View Details <Icon name="chevron_right" className="text-[16px]" />
                </button>
              </div>
            </article>
          ))}
        </div>

        {message && (
          <p className="feedback mt-4 text-center text-[12px] font-bold text-[#006872]">{message}</p>
        )}
      </main>

      {/* Mobile FAB */}
      <button
        type="button"
        className="fixed bottom-24 right-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#006872] text-white shadow-lg md:hidden"
        onClick={() => setMessage('Prescription upload is ready for this demo.')}
      >
        <Icon name="add" filled />
      </button>
      <BottomNav />
    </div>
  );
}
