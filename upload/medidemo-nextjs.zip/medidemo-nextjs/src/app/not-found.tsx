import Link from 'next/link';
import { Icon } from '@/components/ui/icon';

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#fbf9f8] p-4">
      <div className="soft-card w-full max-w-md rounded-2xl p-8 text-center">
        <Icon name="error_outline" className="text-[58px] text-[#ba1a1a]" />
        <h1 className="mt-4 text-[28px] font-extrabold">404</h1>
        <p className="mt-2 text-[18px] font-semibold text-[#3e494a]">Page Not Found</p>
        <p className="mt-2 text-[14px] text-[#6e797b]">
          The page you are looking for does not exist or has been moved.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-[#006872] px-6 py-3 text-[12px] font-bold text-white"
        >
          <Icon name="arrow_back" className="text-[16px]" />
          Back to Home
        </Link>
      </div>
    </div>
  );
}
