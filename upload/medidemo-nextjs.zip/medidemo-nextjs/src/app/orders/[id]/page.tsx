'use client';

import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { BottomNav } from '@/components/layout/bottom-nav';

function TimelineItem({
  icon,
  title,
  detail,
  active = false,
  muted = false,
}: {
  icon: string;
  title: string;
  detail: string;
  active?: boolean;
  muted?: boolean;
}) {
  return (
    <div className={`relative flex items-center gap-4 ${muted ? 'opacity-50' : ''}`}>
      <div
        className={`absolute -left-8 flex h-4 w-4 items-center justify-center rounded-full ring-4 ring-white ${
          active ? 'border-2 border-[#006872] bg-white' : 'bg-[#006872]'
        }`}
      >
        {!active && <Icon name={icon} filled className="text-[10px] text-white" />}
        {active && <span className="h-2 w-2 rounded-full bg-[#006872]" />}
      </div>
      <div>
        <h4 className={`text-[16px] font-semibold ${active ? 'text-[#006872]' : ''}`}>{title}</h4>
        <p className="text-[14px] text-[#3e494a]">{detail}</p>
      </div>
    </div>
  );
}

export default function TrackingPage() {
  return (
    <div className="app-root page-fade pb-20">
      <header className="sticky top-0 z-50 flex h-16 items-center justify-between bg-[#fbf9f8] px-4 shadow-sm">
        <Link href="/" className="p-2 text-[#006872]"><Icon name="menu" /></Link>
        <h1 className="text-[20px] font-bold text-[#006872]">MediDemo</h1>
        <button type="button" className="p-2 text-[#006872]" onClick={() => alert('Your delivery is on schedule.')}>
          <Icon name="notifications" />
        </button>
      </header>

      <main className="mx-auto flex w-full max-w-3xl flex-col gap-8 px-4 py-6">
        {/* Order header */}
        <section>
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-[18px] font-semibold">Order #MD98765</h2>
              <p className="mt-1 text-[14px] text-[#3e494a]">
                Arriving in <b className="text-[#006872]">25 mins</b>
              </p>
            </div>
            <span className="flex items-center gap-1 rounded-full bg-[#00838f] px-3 py-1 text-[12px] font-bold text-white">
              <Icon name="local_shipping" className="text-[16px]" />Active
            </span>
          </div>
          <div className="map-art relative mt-4 h-48 overflow-hidden rounded-xl border border-[#e4e2e1] shadow-sm">
            <div className="absolute left-1/3 top-1/2 flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white p-2 shadow-md">
              <Icon name="two_wheeler" className="text-[#006872]" />
            </div>
            <div className="absolute bottom-7 right-12 flex h-8 w-8 items-center justify-center rounded-full bg-[#b3272a] text-white shadow">
              <Icon name="location_on" filled className="text-[18px]" />
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="soft-card rounded-xl p-4">
          <h3 className="mb-5 text-[18px] font-semibold">Tracking Status</h3>
          <div className="relative space-y-8 pl-8 before:absolute before:bottom-0 before:left-2 before:top-0 before:w-0.5 before:bg-[#00838f]">
            <TimelineItem icon="check" title="Order Placed" detail="10:45 AM, Today" />
            <TimelineItem active icon="local_shipping" title="Out for Delivery" detail="Your order is on the way." />
            <TimelineItem muted icon="check" title="Delivered" detail="Estimated: 11:25 AM" />
          </div>
        </section>

        {/* Delivery details */}
        <section className="soft-card flex flex-col gap-4 rounded-xl p-4">
          <h3 className="text-[18px] font-semibold">Delivery Details</h3>
          <div className="flex gap-3">
            <Icon name="location_on" className="mt-1 text-[#3e494a]" />
            <div>
              <h4 className="text-[14px] font-semibold">Home</h4>
              <p className="text-[14px] leading-5 text-[#3e494a]">
                123 Healthway Ave, Apt 4B<br />
                Wellness City, ST 12345
              </p>
            </div>
          </div>
          <hr className="border-[#e4e2e1]" />
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#d9eeee] text-[#006872]">
              <Icon name="person" />
            </div>
            <div>
              <h4 className="text-[14px] font-semibold">Alex M.</h4>
              <p className="flex items-center gap-1 text-[14px] text-[#3e494a]">
                <Icon name="star" filled className="text-[14px] text-[#ffb957]" />
                4.9 Rating
              </p>
            </div>
          </div>
          <button
            type="button"
            className="mt-2 flex w-full items-center justify-center gap-2 rounded bg-[#006872] py-3 text-[12px] font-bold text-white"
            onClick={() => alert('Calling Alex M.')}
          >
            <Icon name="call" className="text-[18px]" />
            Call Delivery Partner
          </button>
        </section>
      </main>
      <BottomNav />
    </div>
  );
}
