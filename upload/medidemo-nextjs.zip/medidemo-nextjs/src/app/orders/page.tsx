'use client';

import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { BottomNav } from '@/components/layout/bottom-nav';

function OrderCard({
  wide = false,
  status,
  title,
  order,
  date,
  price,
  items,
  trackHref,
}: {
  wide?: boolean;
  status: string;
  title: string;
  order?: string;
  date?: string;
  price: string;
  items: string;
  trackHref: string;
}) {
  const statusStyle =
    status === 'Delivered'
      ? 'bg-[#d9eeee] text-[#006872]'
      : status === 'In Transit'
      ? 'bg-[#ffddb5] text-[#835400]'
      : 'bg-[#eae8e7] text-[#6e797b]';
  const statusIcon =
    status === 'Delivered' ? 'check_circle' : status === 'In Transit' ? 'local_shipping' : 'history';

  return (
    <article className={`soft-card rounded-xl p-4 md:p-6 ${wide ? 'md:col-span-2' : ''}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[12px] font-bold ${statusStyle}`}>
            <Icon name={statusIcon} className="text-[14px]" />
            {status}
          </span>
          {order && <span className="ml-2 text-[11px] text-[#3e494a]">{order}</span>}
          <h3 className="mt-2 text-[18px] font-semibold">{title}</h3>
          {date && <p className="text-[14px] text-[#3e494a]">{date}</p>}
        </div>
        <div className="text-right">
          <p className="text-[18px] font-semibold">{price}</p>
          <p className="text-[11px] text-[#3e494a]">{items}</p>
        </div>
      </div>
      <div className="mt-4 flex items-center justify-end gap-2 border-t border-[#bdc9ca]/40 pt-4">
        <Link
          href={trackHref}
          className="rounded border border-[#006872] px-4 py-2 text-[12px] font-bold text-[#006872]"
        >
          View Details
        </Link>
        <Link
          href={trackHref}
          className="flex items-center gap-1 rounded bg-[#006872] px-4 py-2 text-[12px] font-bold text-white"
        >
          <Icon name="refresh" className="text-[16px]" />
          {status === 'In Transit' ? 'Track' : 'Reorder'}
        </Link>
      </div>
    </article>
  );
}

export default function OrdersPage() {
  return (
    <div className="app-root page-fade pb-16">
      <div className="mx-auto flex min-h-[100dvh] max-w-[1280px]">
        {/* Desktop sidebar */}
        <aside className="side-drawer fixed inset-y-0 left-0 z-40 hidden w-80 flex-col bg-[#f5f3f3] py-6 md:flex">
          <div className="mb-8 flex items-center gap-4 px-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#d9eeee] text-[#006872]">
              <Icon name="person" className="text-[30px]" />
            </div>
            <div>
              <h2 className="text-[18px] font-semibold">Health User</h2>
              <p className="text-[11px] text-[#3e494a]">Premium Member</p>
              <p className="mt-1 flex items-center gap-1 text-[11px] text-[#006872]">
                <Icon name="verified" filled className="text-[14px]" /> Verified Profile
              </p>
            </div>
          </div>
          <div className="flex flex-1 flex-col gap-2 px-4">
            <Link
              href="/prescriptions"
              className="flex items-center gap-4 rounded-full px-4 py-3 text-left text-[#3e494a]"
            >
              <Icon name="description" />My Prescriptions
            </Link>
            <span className="flex items-center gap-4 rounded-full bg-[#fc5d59] px-4 py-3 font-bold text-[#600009]">
              <Icon name="receipt_long" filled />Order History
            </span>
            <Link href="/profile" className="flex items-center gap-4 rounded-full px-4 py-3 text-[#3e494a]">
              <Icon name="person" />Profile
            </Link>
          </div>
        </aside>

        {/* Main content */}
        <div className="w-full md:ml-80">
          <header className="flex h-16 items-center justify-between bg-[#fbf9f8] px-4 md:hidden">
            <Link href="/" className="p-2"><Icon name="menu" /></Link>
            <h1 className="text-[20px] font-bold text-[#006872]">MediDemo</h1>
            <button type="button" className="p-2" onClick={() => alert('No new notifications.')}>
              <Icon name="notifications" />
            </button>
          </header>

          <main className="min-h-[100dvh] bg-white p-4 md:p-8">
            <div className="mx-auto max-w-4xl">
              <header className="mb-8 hidden md:block">
                <h1 className="text-[24px] font-bold">Order History</h1>
                <p className="mt-2 text-[14px] text-[#3e494a]">View and manage your recent pharmacy purchases.</p>
              </header>
              <h2 className="mb-6 text-[18px] font-semibold md:hidden">Recent Orders</h2>

              <div className="grid gap-4 md:grid-cols-2">
                <OrderCard
                  wide
                  status="Delivered"
                  title="Monthly Prescription Refill"
                  order="Order #MD-8492-X"
                  date="Placed on Oct 24, 2023"
                  price="$142.50"
                  items="3 Items"
                  trackHref="/orders/MD98765"
                />
                <OrderCard
                  status="In Transit"
                  title="Vitamin D3 & Zinc Supplement"
                  date="Placed on Oct 18, 2023"
                  price="$28.99"
                  items="1 Item"
                  trackHref="/orders/MD98765"
                />
                <OrderCard
                  status="Oct 02, 2023"
                  title="Allergy Relief Pack"
                  order="Order #MD-7102-Y"
                  price="$45.00"
                  items="2 Items"
                  trackHref="/orders/MD98765"
                />
              </div>
            </div>
          </main>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
