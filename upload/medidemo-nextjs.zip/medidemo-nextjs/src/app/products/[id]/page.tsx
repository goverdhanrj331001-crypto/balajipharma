'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ProductArt } from '@/components/ui/product-art';
import { ProductBand } from '@/components/store/product-band';
import { Icon } from '@/components/ui/icon';
import { useCart } from '@/lib/cart-context';
import { products } from '@/lib/data';

export default function ProductDetailPage() {
  const router = useRouter();
  const { addToCart, cartCount } = useCart();
  const product = products[0]; // In a real app, you'd get this by ID from params
  const [quantity, setQuantity] = useState(1);
  const [favorite, setFavorite] = useState(false);
  const [message, setMessage] = useState('');

  const handleAdd = () => {
    for (let i = 0; i < quantity; i++) addToCart(product);
    setMessage('Added to your cart.');
  };

  const handleBuyNow = () => {
    handleAdd();
    router.push('/cart');
  };

  return (
    <div className="app-root page-fade pb-4">
      {/* Header */}
      <header className="sticky top-0 z-50 flex h-16 items-center justify-between border-b border-[#bdc9ca] bg-[#fbf9f8] px-4">
        <button
          type="button"
          className="rounded-full p-2 text-[#3e494a]"
          onClick={() => router.back()}
        >
          <Icon name="arrow_back" />
        </button>
        <Link href="/" className="text-[20px] font-bold text-[#006872]">
          MediDemo
        </Link>
        <Link href="/cart" className="relative rounded-full p-2 text-[#3e494a]">
          <Icon name="shopping_cart" />
          {cartCount > 0 && (
            <span className="absolute right-0 top-0 rounded-full bg-[#b3272a] px-1 text-[10px] text-white">
              {cartCount}
            </span>
          )}
        </Link>
      </header>

      <main className="mx-auto max-w-4xl">
        {/* Product image */}
        <section className="relative flex h-[350px] items-center justify-center bg-white md:h-[500px]">
          <ProductArt product={product} className="h-full w-full max-w-2xl" />
          <div className="absolute left-4 top-4 flex flex-col gap-2">
            <span className="rounded-full bg-[#b3272a] px-3 py-1 text-[12px] font-bold text-white">15% OFF</span>
            <span className="rounded-full bg-[#ffddb5] px-3 py-1 text-[12px] font-bold text-[#2a1800]">Bestseller</span>
          </div>
          <button
            type="button"
            className="absolute right-4 top-4 rounded-full bg-white/85 p-2 text-[#3e494a] shadow-sm"
            onClick={() => setFavorite(!favorite)}
          >
            <Icon name={favorite ? 'favorite' : 'favorite_border'} filled={favorite} />
          </button>
        </section>

        {/* Product info */}
        <section className="bg-[#fbf9f8] px-4 py-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[14px] uppercase tracking-widest text-[#3e494a]">{product.brand}</p>
              <h1 className="mt-1 text-[20px] font-bold leading-7 md:text-[24px]">
                {product.name.replace(' - Multivitamin Complex 60s', '')}
              </h1>
            </div>
            <button
              type="button"
              className="p-2 text-[#3e494a]"
              onClick={() => setMessage('Product link ready to share.')}
            >
              <Icon name="share" />
            </button>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <span className="text-[#ffb957]">★★★★★</span>
            <span className="text-[14px] text-[#3e494a]">4.5/5 (128 Reviews)</span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-[24px] font-bold text-[#006872]">$100.00</span>
            <span className="text-[14px] text-[#3e494a] line-through">$118.00</span>
            <span className="text-[12px] font-bold text-[#b3272a]">Save $18.00</span>
          </div>
          <p className="text-[11px] text-[#6e797b]">Inclusive of all taxes</p>

          {/* Quantity */}
          <div className="mt-6 flex items-center gap-4">
            <span className="text-[14px] font-medium text-[#3e494a]">Quantity:</span>
            <div className="flex items-center rounded-lg border border-[#bdc9ca] bg-white">
              <button
                type="button"
                className="p-2 text-[#3e494a]"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                <Icon name="remove" />
              </button>
              <span className="w-12 text-center text-[14px] font-semibold">{quantity}</span>
              <button
                type="button"
                className="p-2 text-[#3e494a]"
                onClick={() => setQuantity(quantity + 1)}
              >
                <Icon name="add" />
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-5 flex gap-3">
            <button
              type="button"
              className="flex-1 rounded-lg border-2 border-[#006872] py-3 text-[14px] font-bold text-[#006872]"
              onClick={handleAdd}
            >
              <Icon name="add_shopping_cart" className="mr-1 align-middle" />
              Add to Cart
            </button>
            <button
              type="button"
              className="flex-1 rounded-lg bg-[#006872] py-3 text-[14px] font-bold text-white"
              onClick={handleBuyNow}
            >
              <Icon name="flash_on" className="mr-1 align-middle" />
              Buy Now
            </button>
          </div>
          {message && (
            <p className="feedback mt-3 text-center text-[12px] font-bold text-[#006872]">{message}</p>
          )}
        </section>

        {/* Description tabs */}
        <section className="border-t-8 border-[#f0eded] bg-[#fbf9f8] px-4 py-6">
          <div className="flex gap-2 overflow-x-auto border-b border-[#bdc9ca]">
            <button type="button" className="border-b-2 border-[#006872] px-4 py-2 text-[14px] font-bold text-[#006872]">
              Description
            </button>
            <button type="button" className="px-4 py-2 text-[14px] text-[#3e494a]">Key Benefits</button>
            <button type="button" className="px-4 py-2 text-[14px] text-[#3e494a]">Ingredients</button>
          </div>
          <div className="space-y-4 pt-4 text-[14px] leading-6 text-[#3e494a]">
            <p>
              MediPharma Demo Product 1 is a premium daily multivitamin scientifically formulated to
              support optimal health and well-being. Packed with essential vitamins, minerals, and
              antioxidants, it helps bridge nutritional gaps in your diet.
            </p>
            <p>
              Our advanced slow-release formula ensures maximum absorption throughout the day, providing
              sustained energy and supporting immune function. Suitable for adults of all ages.
            </p>
            <ul className="list-disc pl-5 text-[#1b1c1c]">
              <li>100% vegetarian formulation</li>
              <li>No artificial colors or preservatives</li>
              <li>Clinically tested for efficacy</li>
            </ul>
          </div>
        </section>

        <ProductBand
          title="People Also Bought"
          color="#fbf9f8"
          products={products.slice(1)}
          onAdd={addToCart}
        />
      </main>
    </div>
  );
}
