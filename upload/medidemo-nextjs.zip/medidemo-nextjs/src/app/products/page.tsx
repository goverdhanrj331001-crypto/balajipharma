'use client';

import { useState } from 'react';
import { StoreHeader } from '@/components/layout/store-header';
import { BottomNav } from '@/components/layout/bottom-nav';
import { ProductCard } from '@/components/store/product-card';
import { useCart } from '@/lib/cart-context';
import { products } from '@/lib/data';

const filters = ['All', 'Ayurveda', 'Vitamins', 'Healthcare', 'Diabetes Care'];

export default function ProductsPage() {
  const [activeFilter, setActiveFilter] = useState('All');
  const { addToCart } = useCart();

  return (
    <div className="app-root page-fade pb-16">
      <StoreHeader search={false} />
      <main className="mx-auto w-full max-w-4xl px-4 py-4">
        {/* Filters */}
        <div className="mb-5 flex gap-2 overflow-x-auto no-scrollbar">
          {filters.map((item) => (
            <button
              key={item}
              type="button"
              className={`shrink-0 rounded-full border px-4 py-2 text-[12px] font-bold ${
                activeFilter === item
                  ? 'border-[#00838f] bg-[#00838f] text-white'
                  : 'border-[#bdc9ca] bg-white text-[#3e494a]'
              }`}
              onClick={() => setActiveFilter(item)}
            >
              {item}
            </button>
          ))}
        </div>

        {/* Header */}
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-[18px] font-semibold">All Products</h2>
          <span className="text-[14px] text-[#3e494a]">124 items</span>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 gap-2 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onAdd={addToCart} />
          ))}
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
