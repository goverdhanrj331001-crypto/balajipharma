'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ProductArt } from '@/components/ui/product-art';
import { Icon } from '@/components/ui/icon';
import { useCart } from '@/lib/cart-context';

export default function CartPage() {
  const router = useRouter();
  const { cart, removeFromCart, updateQuantity, cartCount, cartTotal } = useCart();

  return (
    <div className="app-root page-fade pb-32">
      {/* Header */}
      <header className="fixed top-0 z-50 flex h-16 w-full items-center justify-between border-b border-[#bdc9ca] bg-[#fbf9f8] px-4">
        <Link href="/" className="rounded-full p-2 text-[#3e494a]">
          <Icon name="menu" />
        </Link>
        <Link href="/" className="text-[20px] font-bold text-[#006872]">MediDemo</Link>
        <Link href="/profile" className="rounded-full p-2 text-[#3e494a]">
          <Icon name="account_circle" />
        </Link>
      </header>

      <main className="mx-auto max-w-2xl space-y-6 px-4 pt-20">
        <div className="flex items-center justify-between">
          <h1 className="text-[20px] font-bold">Your Cart</h1>
          <span className="rounded-full bg-[#eae8e7] px-3 py-1 text-[12px] font-bold text-[#3e494a]">
            {cartCount} Items
          </span>
        </div>

        {/* Cart items */}
        <section className="space-y-3">
          {cart.map((item) => (
            <div key={item.id} className="soft-card flex gap-4 rounded-xl p-4">
              <ProductArt product={item} className="h-20 w-20 shrink-0 rounded-lg" />
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between">
                  <h3 className="text-[18px] font-semibold">{item.shortName}</h3>
                  <button
                    type="button"
                    className="p-1 text-[#6e797b] hover:text-[#ba1a1a]"
                    onClick={() => removeFromCart(item.id)}
                  >
                    <Icon name="delete" className="text-[20px]" />
                  </button>
                </div>
                <p className="mt-1 text-[14px] text-[#3e494a]">{item.note}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-[18px] font-semibold text-[#006872]">
                    ${item.price.toFixed(2)}
                  </span>
                  <div className="flex items-center rounded-full border border-[#bdc9ca] bg-[#f0eded] p-1">
                    <button
                      type="button"
                      className="flex h-8 w-8 items-center justify-center rounded-full text-[#006872]"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    >
                      <Icon name="remove" className="text-[18px]" />
                    </button>
                    <span className="w-6 text-center text-[12px] font-bold">{item.quantity}</span>
                    <button
                      type="button"
                      className="flex h-8 w-8 items-center justify-center rounded-full text-[#006872]"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    >
                      <Icon name="add" className="text-[18px]" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </section>

        {/* Empty state */}
        {cart.length === 0 && (
          <div className="soft-card rounded-xl p-8 text-center">
            <Icon name="shopping_cart" className="text-[42px] text-[#00838f]" />
            <p className="mt-3 text-[14px] text-[#3e494a]">Your cart is waiting for something good.</p>
            <Link
              href="/products"
              className="mt-4 inline-block rounded-lg bg-[#006872] px-5 py-2 text-[12px] font-bold text-white"
            >
              Browse Products
            </Link>
          </div>
        )}

        {/* Coupon */}
        <section className="soft-card flex items-center gap-3 rounded-xl p-4">
          <Icon name="local_offer" className="text-[#006872]" />
          <span className="flex-1 text-[14px]">Apply Coupon or Promo Code</span>
          <Icon name="chevron_right" className="text-[#3e494a]" />
        </section>

        {/* Bill summary */}
        <section className="soft-card space-y-3 rounded-xl p-4">
          <h3 className="border-b border-[#bdc9ca]/30 pb-2 text-[18px] font-semibold">Bill Summary</h3>
          <div className="flex justify-between text-[14px] text-[#3e494a]">
            <span>Item Total</span>
            <span>${cartTotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-[14px] text-[#006872]">
            <span>Discount</span>
            <span>-$5.00</span>
          </div>
          <div className="flex justify-between text-[14px] text-[#3e494a]">
            <span>Delivery Charges</span>
            <span>$3.00</span>
          </div>
          <div className="flex justify-between border-t border-[#bdc9ca]/30 pt-3 text-[18px] font-semibold">
            <span>Total Amount</span>
            <span className="text-[#006872]">${Math.max(0, cartTotal - 2).toFixed(2)}</span>
          </div>
        </section>
      </main>

      {/* Checkout CTA */}
      <div className="sticky-action fixed bottom-16 z-40 w-full border-t border-[#bdc9ca]/30 bg-[#fbf9f8] p-4 md:bottom-0">
        <button
          type="button"
          disabled={!cart.length}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#006872] py-4 text-[12px] font-bold text-white disabled:cursor-not-allowed disabled:opacity-50"
          onClick={() => router.push('/checkout')}
        >
          Proceed to Checkout <Icon name="arrow_forward" className="text-[18px]" />
        </button>
      </div>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 z-50 flex h-16 w-full items-center justify-around border-t border-[#bdc9ca] bg-[#fbf9f8] md:hidden">
        <Link href="/" className="flex flex-col items-center text-[#3e494a]">
          <Icon name="storefront" />
          <span className="text-[11px]">Shop</span>
        </Link>
        <Link href="/categories" className="flex flex-col items-center text-[#3e494a]">
          <Icon name="health_and_safety" />
          <span className="text-[11px]">Concerns</span>
        </Link>
        <button type="button" className="flex flex-col items-center rounded-full bg-[#00838f] px-4 py-1 text-white">
          <Icon name="shopping_cart" filled />
          <span className="text-[11px]">Cart</span>
        </button>
        <Link href="/profile" className="flex flex-col items-center text-[#3e494a]">
          <Icon name="person" />
          <span className="text-[11px]">Account</span>
        </Link>
      </nav>
    </div>
  );
}
