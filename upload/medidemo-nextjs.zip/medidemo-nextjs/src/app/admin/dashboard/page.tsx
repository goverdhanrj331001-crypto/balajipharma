import Link from 'next/link';
import { AdminLayout } from '@/components/admin/admin-layout';
import { StatCard, SectionCard, AdminTable, StatusRow } from '@/components/admin/admin-ui';
import { Icon } from '@/components/ui/icon';

const dashboardRows = [
  ['#MD-8492-X', 'Health User', 'Monthly Prescription Refill', '$142.50', 'Delivered'],
  ['#MD-8498-K', 'Ava Morgan', 'Full Body Checkup', '$149.00', 'Processing'],
  ['#MD-8501-Q', 'Marcus Chen', 'Vitamin D3 & Zinc', '$28.99', 'In Transit'],
  ['#MD-8508-P', 'Elena Stone', 'Diabetes Care Kit', '$64.50', 'Delivered'],
];

const topProducts = [
  ['Multivitamin Complex', '1,248 sold', '68%', 'bg-[#006872]'],
  ['Ashwagandha Extract', '986 sold', '54%', 'bg-[#00838f]'],
  ['Blood Glucose Monitor', '734 sold', '42%', 'bg-[#a46a00]'],
  ['Muscle Relief Gel', '512 sold', '31%', 'bg-[#fc5d59]'],
];

const recentActivity = [
  ['inventory', 'Inventory alert', '5 products are low in stock', '10 min ago'],
  ['person_add', 'New customer', 'Ava Morgan created an account', '42 min ago'],
  ['shopping_bag', 'New order', 'Order #MD-8508-P was placed', '1 hr ago'],
  ['science', 'Lab result ready', 'CBC report is available', '2 hrs ago'],
];

export default function AdminDashboardPage() {
  return (
    <AdminLayout title="Sales Overview">
      {/* Page heading */}
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[13px] text-[#6e797b]">Sunday, August 16, 2026</p>
          <h2 className="mt-1 text-[24px] font-extrabold tracking-tight">Sales Overview</h2>
          <p className="mt-1 text-[13px] text-[#3e494a]">A clear view of your pharmacy operations today.</p>
        </div>
        <button
          type="button"
          className="flex items-center gap-2 rounded-lg border border-[#bdc9ca] bg-white px-3 py-2 text-[12px] font-bold text-[#3e494a]"
        >
          <Icon name="calendar_today" className="text-[16px]" /> Last 30 days{' '}
          <Icon name="expand_more" className="text-[16px]" />
        </button>
      </div>

      {/* KPI cards */}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total Revenue" value="$124,563" delta="+12.5% from last month" icon="payments" />
        <StatCard label="Total Orders" value="1,245" delta="+8.2% from last month" icon="shopping_bag" tone="blue" />
        <StatCard label="New Customers" value="342" delta="+15.4% from last month" icon="group_add" tone="gold" />
        <StatCard label="Pending Actions" value="89" delta="Needs your attention" icon="pending_actions" tone="red" />
      </div>

      {/* Charts row */}
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.4fr_1fr]">
        <SectionCard
          title="Sales Overview"
          action={
            <div className="flex rounded-lg bg-[#f0eded] p-1 text-[11px]">
              <button type="button" className="rounded-md bg-white px-3 py-1.5 font-bold text-[#006872]">Weekly</button>
              <button type="button" className="px-3 py-1.5 text-[#6e797b]">Monthly</button>
            </div>
          }
        >
          <div className="relative h-[235px] overflow-hidden rounded-lg bg-[#f8fbfb] p-4">
            <div className="absolute inset-x-4 top-8 border-t border-dashed border-[#bdc9ca]/60" />
            <div className="absolute inset-x-4 top-1/2 border-t border-dashed border-[#bdc9ca]/60" />
            <div className="absolute inset-x-4 bottom-9 border-t border-dashed border-[#bdc9ca]/60" />
            <div className="absolute inset-x-6 bottom-9 top-8">
              <svg viewBox="0 0 700 190" preserveAspectRatio="none" className="h-full w-full">
                <defs>
                  <linearGradient id="sales-fill" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0" stopColor="#00838f" stopOpacity=".25" />
                    <stop offset="1" stopColor="#00838f" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <path
                  d="M0 148 C55 132 60 112 118 126 S184 80 238 104 S300 88 352 94 S414 51 470 75 S534 34 585 58 S644 25 700 42 L700 190 L0 190Z"
                  fill="url(#sales-fill)"
                />
                <path
                  d="M0 148 C55 132 60 112 118 126 S184 80 238 104 S300 88 352 94 S414 51 470 75 S534 34 585 58 S644 25 700 42"
                  fill="none"
                  stroke="#006872"
                  strokeWidth="3"
                />
              </svg>
            </div>
            <div className="absolute inset-x-6 bottom-2 flex justify-between text-[10px] text-[#6e797b]">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
                <span key={d}>{d}</span>
              ))}
            </div>
          </div>
        </SectionCard>

        <SectionCard
          title="Recent Activity"
          action={
            <button type="button" className="text-[12px] font-bold text-[#006872]">View All</button>
          }
        >
          <div className="space-y-4">
            {recentActivity.map(([icon, title, text, time]) => (
              <div key={title} className="flex gap-3">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#d9eeee] text-[#006872]">
                  <Icon name={icon} className="text-[17px]" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[12px] font-bold">{title}</p>
                  <p className="truncate text-[11px] text-[#3e494a]">{text}</p>
                </div>
                <span className="whitespace-nowrap text-[10px] text-[#6e797b]">{time}</span>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      {/* Tables row */}
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.4fr_1fr]">
        <SectionCard
          title="Recent Orders"
          action={
            <Link href="/admin/orders" className="text-[12px] font-bold text-[#006872]">View All</Link>
          }
        >
          <AdminTable headers={['Order ID', 'Customer', 'Order', 'Amount', 'Status']} rows={dashboardRows} />
        </SectionCard>

        <SectionCard title="Top Products">
          <div className="space-y-4">
            {topProducts.map(([name, sold, width, barColor]) => (
              <div key={name}>
                <div className="mb-1 flex justify-between text-[12px]">
                  <span className="font-semibold">{name}</span>
                  <span className="text-[#6e797b]">{sold}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-[#eae8e7]">
                  <div className={`h-full rounded-full ${barColor}`} style={{ width }} />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      {/* System status */}
      <div className="mt-5 grid gap-5 md:grid-cols-3">
        <SectionCard title="System Status">
          <StatusRow label="API Services" status="Operational" good />
          <StatusRow label="Payment Gateway" status="Operational" good />
          <StatusRow label="Database" status="Operational" good />
        </SectionCard>
        <SectionCard title="Critical Items">
          <div className="flex items-center gap-3 rounded-lg bg-[#fff4f2] p-3">
            <Icon name="warning" className="text-[#ba1a1a]" />
            <div>
              <p className="text-[12px] font-bold">7 products need restocking</p>
              <p className="text-[11px] text-[#3e494a]">Review inventory now</p>
            </div>
          </div>
        </SectionCard>
        <SectionCard title="Quick Actions">
          <div className="grid gap-2">
            <Link href="/admin/inventory/new" className="flex items-center gap-2 rounded-lg border border-[#bdc9ca] px-3 py-2 text-[12px] font-bold text-[#006872] hover:bg-[#f5f3f3]">
              <Icon name="add_box" className="text-[18px]" />Add Product
            </Link>
            <Link href="/admin/lab-orders/new" className="flex items-center gap-2 rounded-lg border border-[#bdc9ca] px-3 py-2 text-[12px] font-bold text-[#006872] hover:bg-[#f5f3f3]">
              <Icon name="science" className="text-[18px]" />Add Lab Test
            </Link>
          </div>
        </SectionCard>
      </div>
    </AdminLayout>
  );
}
