'use client';

import { useState } from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { SectionCard, Field, Toggle } from '@/components/admin/admin-ui';

const settingsMenu = ['General', 'Notifications', 'Payments', 'Delivery Zones', 'Team & Roles', 'Security'];

export default function AdminSettingsPage() {
  const [saved, setSaved] = useState(false);
  const [storeOpen, setStoreOpen] = useState(true);

  return (
    <AdminLayout title="System Settings">
      <div className="mb-6">
        <h2 className="text-[24px] font-extrabold tracking-tight">System Settings</h2>
        <p className="mt-1 text-[13px] text-[#3e494a]">Configure the way MediDemo operates for your team.</p>
      </div>

      <div className="grid gap-5 xl:grid-cols-[260px_1fr]">
        {/* Sidebar nav */}
        <div className="soft-card h-fit rounded-xl bg-white p-2">
          {settingsMenu.map((item, i) => (
            <button
              key={item}
              type="button"
              className={`flex w-full items-center justify-between rounded-lg px-3 py-3 text-left text-[12px] font-bold ${
                i === 0 ? 'bg-[#d9eeee] text-[#006872]' : 'text-[#3e494a] hover:bg-[#f5f3f3]'
              }`}
            >
              {item}
            </button>
          ))}
        </div>

        {/* Settings content */}
        <div className="space-y-5">
          <SectionCard title="General Information">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Business Name" placeholder="MediDemo Pharmacy" />
              <Field label="Support Email" placeholder="support@medidemo.com" />
              <Field label="Phone Number" placeholder="+1 (555) 123-4567" />
              <Field label="Timezone" select options={['Asia/Calcutta', 'America/New_York', 'Europe/London']} />
            </div>
          </SectionCard>

          <SectionCard title="Store Status">
            <div className="flex items-center justify-between rounded-lg bg-[#f8fbfb] p-4">
              <div>
                <p className="text-[13px] font-bold">Store is open</p>
                <p className="mt-1 text-[11px] text-[#6e797b]">Customers can browse and place orders.</p>
              </div>
              <Toggle label="" enabled={storeOpen} onClick={() => setStoreOpen(!storeOpen)} />
            </div>
          </SectionCard>

          <div className="flex justify-end">
            <button
              type="button"
              className="rounded-lg bg-[#006872] px-5 py-2.5 text-[12px] font-bold text-white"
              onClick={() => setSaved(true)}
            >
              {saved ? 'Changes Saved ✓' : 'Save Changes'}
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
