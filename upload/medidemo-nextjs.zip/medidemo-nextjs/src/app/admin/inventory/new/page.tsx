'use client';

import { useState } from 'react';
import Link from 'next/link';
import { AdminLayout } from '@/components/admin/admin-layout';
import { SectionCard, Field, Toggle } from '@/components/admin/admin-ui';
import { Icon } from '@/components/ui/icon';

export default function NewProductPage() {
  const [saved, setSaved] = useState(false);
  const [enabled, setEnabled] = useState(true);

  if (saved) {
    return (
      <AdminLayout title="Add New Product">
        <div className="mx-auto max-w-xl py-10">
          <div className="soft-card rounded-2xl bg-white p-8 text-center">
            <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#d9eeee] text-[#006872]">
              <Icon name="check_circle" filled className="text-[42px]" />
            </span>
            <h2 className="mt-5 text-[22px] font-bold">Product saved</h2>
            <p className="mt-2 text-[13px] text-[#3e494a]">
              The new record is now ready for review in your MediDemo catalog.
            </p>
            <Link
              href="/admin/inventory"
              className="mt-6 inline-block rounded-lg bg-[#006872] px-5 py-2.5 text-[12px] font-bold text-white"
            >
              Back to Inventory
            </Link>
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Add New Product">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-[24px] font-extrabold tracking-tight">Add New Product</h2>
          <p className="mt-1 text-[13px] text-[#3e494a]">Create a new catalog item with clear clinical details.</p>
        </div>
        <div className="flex gap-2">
          <Link
            href="/admin/inventory"
            className="rounded-lg border border-[#bdc9ca] bg-white px-4 py-2.5 text-[12px] font-bold"
          >
            Discard
          </Link>
          <button
            type="button"
            className="rounded-lg bg-[#006872] px-4 py-2.5 text-[12px] font-bold text-white"
            onClick={() => setSaved(true)}
          >
            Save Product
          </button>
        </div>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1fr_320px]">
        <div className="space-y-5">
          <SectionCard title="Product Information">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Product Name" placeholder="e.g. Multivitamin Complex" wide />
              <Field label="Category" select options={['Antibiotics', 'Pain Relief', 'Vitamins & Supplements', 'First Aid']} />
              <Field label="Brand" placeholder="MediPharma" />
              <Field label="SKU" placeholder="MED-000" />
              <Field label="Description" textarea wide placeholder="Add useful information for customers and staff..." />
            </div>
          </SectionCard>

          <SectionCard title="Pricing & Inventory">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Price" placeholder="$0.00" />
              <Field label="Stock Quantity" placeholder="0" />
              <Field label="Reorder Level" placeholder="50" />
              <Field label="Discount" placeholder="15%" />
            </div>
          </SectionCard>

          <SectionCard title="Clinical Requirements">
            <div className="grid gap-3 sm:grid-cols-2">
              <Toggle label="Prescription required" enabled={enabled} onClick={() => setEnabled(!enabled)} />
              <Toggle label="Show as bestseller" enabled={enabled} onClick={() => setEnabled(!enabled)} />
              <Toggle label="Visible in catalog" enabled={enabled} onClick={() => setEnabled(!enabled)} />
            </div>
          </SectionCard>
        </div>

        <div className="space-y-5">
          <SectionCard title="Product Media">
            <div className="flex min-h-44 flex-col items-center justify-center rounded-xl border border-dashed border-[#bdc9ca] bg-[#f8fbfb] p-5 text-center">
              <Icon name="cloud_upload" className="text-[38px] text-[#006872]" />
              <p className="mt-3 text-[13px] font-bold">Drop media here</p>
              <p className="mt-1 text-[11px] text-[#6e797b]">PNG, JPG up to 5MB</p>
              <button
                type="button"
                className="mt-4 rounded-lg border border-[#006872] px-4 py-2 text-[11px] font-bold text-[#006872]"
                onClick={() => alert('Media picker opened.')}
              >
                Browse Files
              </button>
            </div>
          </SectionCard>

          <SectionCard title="Publishing">
            <Toggle label="Publish immediately" enabled={enabled} onClick={() => setEnabled(!enabled)} />
            <p className="mt-3 text-[11px] leading-4 text-[#6e797b]">
              You can adjust visibility and availability later from management.
            </p>
          </SectionCard>
        </div>
      </div>
    </AdminLayout>
  );
}
