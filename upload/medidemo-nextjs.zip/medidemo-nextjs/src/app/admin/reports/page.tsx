import { AdminLayout } from '@/components/admin/admin-layout';
import { SectionCard, AdminTable, StatusRow } from '@/components/admin/admin-ui';

const barData = [
  ['Jan', 45], ['Feb', 62], ['Mar', 55], ['Apr', 78],
  ['May', 66], ['Jun', 88], ['Jul', 72], ['Aug', 94],
] as const;

export default function AdminReportsPage() {
  return (
    <AdminLayout title="Analytics & Reports">
      <div className="mb-6">
        <h2 className="text-[24px] font-extrabold tracking-tight">Reports & Analytics</h2>
        <p className="mt-1 text-[13px] text-[#3e494a]">Understand sales, customer growth, and pharmacy performance.</p>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        {/* Bar chart */}
        <SectionCard title="Revenue by Channel">
          <div className="flex h-64 items-end gap-3 rounded-lg bg-[#f8fbfb] px-5 pb-5 pt-8">
            {barData.map(([month, value]) => (
              <div key={month} className="flex flex-1 flex-col items-center gap-2">
                <div
                  className="w-full rounded-t bg-[#00838f] transition hover:bg-[#006872]"
                  style={{ height: `${value}%` }}
                />
                <span className="text-[10px] text-[#6e797b]">{month}</span>
              </div>
            ))}
          </div>
        </SectionCard>

        {/* Donut chart */}
        <SectionCard title="Order Mix">
          <div className="flex items-center gap-7 py-5">
            <div
              className="relative flex h-40 w-40 shrink-0 items-center justify-center rounded-full"
              style={{
                background:
                  'conic-gradient(#006872 0 48%, #ffb957 48% 73%, #fc5d59 73% 91%, #d9eeee 91% 100%)',
              }}
            >
              <div className="flex h-24 w-24 items-center justify-center rounded-full bg-white text-center text-[12px] font-bold">
                1,245
                <br />
                <span className="font-normal text-[#6e797b]">orders</span>
              </div>
            </div>
            <div className="space-y-3 text-[12px]">
              <StatusRow label="Medicine" status="48%" good />
              <StatusRow label="Lab testing" status="25%" good />
              <StatusRow label="Wellness" status="18%" good />
              <StatusRow label="Other" status="9%" good />
            </div>
          </div>
        </SectionCard>
      </div>

      <div className="mt-5">
        <SectionCard
          title="Performance Summary"
          action={
            <button type="button" className="rounded-lg bg-[#006872] px-3 py-2 text-[11px] font-bold text-white">
              Download Report
            </button>
          }
        >
          <AdminTable
            headers={['Metric', 'This Period', 'Previous Period', 'Change']}
            rows={[
              ['Revenue', '$124,563', '$110,710', '+12.5%'],
              ['Orders', '1,245', '1,150', '+8.2%'],
              ['Average Order Value', '$100.05', '$96.27', '+3.9%'],
              ['New Customers', '342', '296', '+15.4%'],
            ]}
            showAction={false}
          />
        </SectionCard>
      </div>
    </AdminLayout>
  );
}
