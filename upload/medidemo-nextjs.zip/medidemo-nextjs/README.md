# MediDemo – Online Pharmacy & Healthcare Platform

A full-featured pharmacy e-commerce demo app built with **Next.js 15**, **TypeScript**, and **Tailwind CSS**.

## Features

### Customer Store
- 🏠 **Homepage** – Hero, product bands, categories, health concerns, featured brands
- 🗂️ **Categories** – Browse all health categories
- 💊 **Products** – Listing with filters + Product detail pages
- 🛒 **Cart** – Add/remove items, quantity management, bill summary
- 💳 **Checkout** – Address, delivery slot, payment method selection
- 📦 **Orders** – Order history with tracking
- 🔬 **Lab Tests** – Health packages, test details, home sample scheduling
- 👤 **Profile** – Account management, prescriptions, health records
- 🔐 **Login** – Customer and admin login flows

### Admin Panel (`/admin`)
- 📊 **Dashboard** – KPIs, sales chart, recent activity, top products
- 📋 **Orders Overview** – All orders, medicine orders, lab testing orders
- 📦 **Inventory** – Stock management, add/edit products
- 🗂️ **Categories** – Catalog organization
- 👥 **Users & Employees** – Staff and patient management
- 🎟️ **Support Tickets** – Customer support queue
- 📈 **Reports** – Revenue charts, order mix, performance summary
- ⚙️ **Settings** – Business configuration

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 15 (App Router) |
| Language | TypeScript 5.6 |
| Styling | Tailwind CSS 3 + CSS Variables |
| Icons | Material Symbols Outlined (Google Fonts) |
| Font | Manrope (Google Fonts) |
| State | React Context (Cart) |
| Data Fetching | TanStack Query (ready to use) |

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── layout.tsx          # Root layout with CartProvider
│   ├── page.tsx            # Homepage
│   ├── categories/         # Category listing
│   ├── products/           # Product listing + [id] detail
│   ├── cart/               # Shopping cart
│   ├── checkout/           # Checkout flow
│   ├── orders/             # Order history + [id] tracking
│   ├── profile/            # User profile
│   ├── prescriptions/      # Prescription management
│   ├── lab-tests/          # Lab tests + [id] detail + schedule
│   ├── login/              # Customer login
│   └── admin/              # Full admin panel
│       ├── dashboard/
│       ├── orders/
│       ├── medicine-orders/
│       ├── lab-orders/
│       ├── inventory/
│       ├── categories/
│       ├── users/
│       ├── employees/
│       ├── support/
│       ├── reports/
│       ├── settings/
│       └── login/
├── components/
│   ├── ui/                 # Shared UI primitives (Icon, ProductArt)
│   ├── layout/             # StoreHeader, BottomNav
│   ├── store/              # ProductCard, ProductBand
│   └── admin/              # AdminLayout, AdminSidebar, AdminUI, AdminDataPage
├── lib/
│   ├── data.ts             # Mock data (products, categories, lab tests)
│   ├── utils.ts            # cn() helper
│   └── cart-context.tsx    # Cart state (Context + hook)
└── types/
    └── index.ts            # Shared TypeScript types
```

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Type-check
npm run typecheck
```

Open [http://localhost:3000](http://localhost:3000) to view the store.  
Open [http://localhost:3000/admin](http://localhost:3000/admin) for the admin panel.

## Design System

The app uses a teal-based healthcare palette:

| Token | Value | Usage |
|-------|-------|-------|
| Brand | `#006872` | Primary buttons, links, active states |
| Brand light | `#00838f` | Secondary buttons, accents |
| Accent red | `#fc5d59` | Active bottom nav, badges |
| Background | `#fbf9f8` | Page backgrounds |
| Surface | `#f5f3f3` | Cards, sections |

## Extending the Project

- **Add real API**: Replace mock data in `src/lib/data.ts` with API calls using TanStack Query
- **Add authentication**: Implement auth in `src/app/login/page.tsx` and protect `/admin` routes with Next.js middleware
- **Add database**: Connect Drizzle ORM with PostgreSQL (the original project already had the schema set up in `lib/db/`)
- **Add search**: Wire up the search inputs to a search API or client-side filter
